import { EventSchemaType } from "../eventsSchema";
declare const handleEndShed: (device_id: string, startTime?: Date) => Promise<EventSchemaType>;
export { handleEndShed };
