import { EventSchemaType } from "../eventsSchema";
declare const handleCriticalPeak: (device_id: string, startTime?: Date) => Promise<EventSchemaType>;
export { handleCriticalPeak };
