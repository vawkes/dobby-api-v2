"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleAdvancedLoadUp = void 0;
const uuid_1 = require("uuid");
const eventType_ts_1 = require("../models/eventType.ts");
const eventsSchema_ts_1 = require("../eventsSchema.ts");
const sendToDobby_ts_1 = require("../../utils/sendToDobby.ts");
const saveEvent_ts_1 = require("../../utils/saveEvent.ts");
/**
 * Units field specification:
 * 0x00 - 1 watt-hour (Wh)
 * 0x01 - 10 Wh
 * 0x02 - 100 Wh
 * 0x03 - 1000 Wh (1 kWh)
 * 0x04 to 0xFE - Reserved for future use - Do not use
 * 0xFF - Used in response to GetAdvancedLoadUp, indicates advanced load up is not active
 *
 * Value field specification:
 * 0x0000 - No Effect on the SGD, but the SGD should respond with Response Code = Success if this
 *          Advanced Load Up command is implemented and the necessary mixing valve or other safety
 *          precautions are in place. When using this value, units must be set to 0xFF.
 * 0x0001 to 0xFFFE - This quantity of Units specifies the minimum amount of energy that the SGD
 *                    should store above the amount that would be stored during normal operation.
 * 0xFFFF - Store as much energy as possible above the normal amount, while maintaining the safety
 *          and efficiency of the SGD and any temperature limiting device.
 */
const handleAdvancedLoadUp = async (deviceId, startTime, duration, value, units, suggestedLoadUpEfficiency, eventId, startRandomization, endRandomization) => {
    try {
        // Validate units
        if (units < 0 || units > 0xFF) {
            throw new Error('Invalid units value. Must be between 0x00 and 0xFF');
        }
        if (units >= 0x04 && units <= 0xFE) {
            throw new Error('Units value is in reserved range (0x04 to 0xFE)');
        }
        // Validate value
        if (value < 0 || value > 0xFFFF) {
            throw new Error('Invalid value. Must be between 0x0000 and 0xFFFF');
        }
        // Validate value and units combination
        if (value === 0x0000 && units !== 0xFF) {
            throw new Error('When value is 0x0000, units must be set to 0xFF');
        }
        // Convert start time to UTC seconds since 1/1/2000
        const startTimeUTC = Math.floor((startTime.getTime() - new Date('2000-01-01').getTime()) / 1000);
        // Create the message payload according to the spec
        const buffer = new ArrayBuffer(17);
        const view = new DataView(buffer);
        // Command Type
        view.setUint8(0, eventType_ts_1.EventMap.SET_ADVANCED_LOAD_UP);
        // Event Duration in Minutes (2 bytes)
        view.setUint16(1, duration, true);
        // Value (2 bytes)
        view.setUint16(3, value, true);
        // Units
        view.setUint8(5, units, true);
        // Suggested Load Up Efficiency
        view.setUint8(6, suggestedLoadUpEfficiency);
        // Event ID (4 bytes)
        const eventIdNum = parseInt(eventId.replace(/-/g, '').substring(0, 8), 16);
        view.setUint32(7, eventIdNum, true);
        // Start Time UTC (4 bytes)
        view.setUint32(11, startTimeUTC, true);
        // Start Randomization
        view.setUint8(15, startRandomization);
        // End Randomization
        view.setUint8(16, endRandomization);
        // Send the message to Dobby
        const sentToDobby = await (0, sendToDobby_ts_1.sendToDobby)(deviceId, buffer);
        // Create the event record
        const event = {
            event_id: (0, uuid_1.v4)(),
            event_type: eventsSchema_ts_1.EventType.ADVANCED_LOAD_UP,
            event_data: {
                device_id: deviceId,
                start_time: startTime.toISOString(),
                duration,
                value,
                units,
                suggested_load_up_efficiency: suggestedLoadUpEfficiency,
                event_id: eventId,
                start_randomization: startRandomization,
                end_randomization: endRandomization,
                message: Array.from(new Uint8Array(buffer)),
                event_sent: sentToDobby
            }
        };
        // Save the event to DynamoDB
        await (0, saveEvent_ts_1.saveEventToDynamoDB)(event);
        return event;
    }
    catch (error) {
        console.error("Error handling advanced load up event:", error);
        return null;
    }
};
exports.handleAdvancedLoadUp = handleAdvancedLoadUp;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWR2YW5jZWRMb2FkVXAuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJhZHZhbmNlZExvYWRVcC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSwrQkFBb0M7QUFDcEMseURBQWtEO0FBQ2xELHdEQUFnRTtBQUNoRSwrREFBeUQ7QUFDekQsMkRBQStEO0FBRS9EOzs7Ozs7Ozs7Ozs7Ozs7OztHQWlCRztBQUNJLE1BQU0sb0JBQW9CLEdBQUcsS0FBSyxFQUNyQyxRQUFnQixFQUNoQixTQUFlLEVBQ2YsUUFBZ0IsRUFDaEIsS0FBYSxFQUNiLEtBQWEsRUFDYix5QkFBaUMsRUFDakMsT0FBZSxFQUNmLGtCQUEwQixFQUMxQixnQkFBd0IsRUFDTyxFQUFFO0lBQ2pDLElBQUksQ0FBQztRQUNELGlCQUFpQjtRQUNqQixJQUFJLEtBQUssR0FBRyxDQUFDLElBQUksS0FBSyxHQUFHLElBQUksRUFBRSxDQUFDO1lBQzVCLE1BQU0sSUFBSSxLQUFLLENBQUMsb0RBQW9ELENBQUMsQ0FBQztRQUMxRSxDQUFDO1FBQ0QsSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLEtBQUssSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUNqQyxNQUFNLElBQUksS0FBSyxDQUFDLGlEQUFpRCxDQUFDLENBQUM7UUFDdkUsQ0FBQztRQUVELGlCQUFpQjtRQUNqQixJQUFJLEtBQUssR0FBRyxDQUFDLElBQUksS0FBSyxHQUFHLE1BQU0sRUFBRSxDQUFDO1lBQzlCLE1BQU0sSUFBSSxLQUFLLENBQUMsa0RBQWtELENBQUMsQ0FBQztRQUN4RSxDQUFDO1FBRUQsdUNBQXVDO1FBQ3ZDLElBQUksS0FBSyxLQUFLLE1BQU0sSUFBSSxLQUFLLEtBQUssSUFBSSxFQUFFLENBQUM7WUFDckMsTUFBTSxJQUFJLEtBQUssQ0FBQyxpREFBaUQsQ0FBQyxDQUFDO1FBQ3ZFLENBQUM7UUFFRCxtREFBbUQ7UUFDbkQsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsR0FBRyxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO1FBRWpHLG1EQUFtRDtRQUNuRCxNQUFNLE1BQU0sR0FBRyxJQUFJLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNuQyxNQUFNLElBQUksR0FBRyxJQUFJLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUVsQyxlQUFlO1FBQ2YsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsdUJBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1FBRWhELHNDQUFzQztRQUN0QyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFFbEMsa0JBQWtCO1FBQ2xCLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQztRQUUvQixRQUFRO1FBQ1IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBRTlCLCtCQUErQjtRQUMvQixJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSx5QkFBeUIsQ0FBQyxDQUFDO1FBRTVDLHFCQUFxQjtRQUNyQixNQUFNLFVBQVUsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUMzRSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFFcEMsMkJBQTJCO1FBQzNCLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxFQUFFLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztRQUV2QyxzQkFBc0I7UUFDdEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsa0JBQWtCLENBQUMsQ0FBQztRQUV0QyxvQkFBb0I7UUFDcEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztRQUVwQyw0QkFBNEI7UUFDNUIsTUFBTSxXQUFXLEdBQUcsTUFBTSxJQUFBLDRCQUFXLEVBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBRXhELDBCQUEwQjtRQUMxQixNQUFNLEtBQUssR0FBb0I7WUFDM0IsUUFBUSxFQUFFLElBQUEsU0FBTSxHQUFFO1lBQ2xCLFVBQVUsRUFBRSwyQkFBUyxDQUFDLGdCQUFnQjtZQUN0QyxVQUFVLEVBQUU7Z0JBQ1IsU0FBUyxFQUFFLFFBQVE7Z0JBQ25CLFVBQVUsRUFBRSxTQUFTLENBQUMsV0FBVyxFQUFFO2dCQUNuQyxRQUFRO2dCQUNSLEtBQUs7Z0JBQ0wsS0FBSztnQkFDTCw0QkFBNEIsRUFBRSx5QkFBeUI7Z0JBQ3ZELFFBQVEsRUFBRSxPQUFPO2dCQUNqQixtQkFBbUIsRUFBRSxrQkFBa0I7Z0JBQ3ZDLGlCQUFpQixFQUFFLGdCQUFnQjtnQkFDbkMsT0FBTyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQzNDLFVBQVUsRUFBRSxXQUFXO2FBQzFCO1NBQ0osQ0FBQztRQUVGLDZCQUE2QjtRQUM3QixNQUFNLElBQUEsa0NBQW1CLEVBQUMsS0FBSyxDQUFDLENBQUM7UUFFakMsT0FBTyxLQUFLLENBQUM7SUFDakIsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDYixPQUFPLENBQUMsS0FBSyxDQUFDLHdDQUF3QyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQy9ELE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7QUFDTCxDQUFDLENBQUM7QUEvRlcsUUFBQSxvQkFBb0Isd0JBK0YvQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHY0IGFzIHV1aWR2NCB9IGZyb20gJ3V1aWQnO1xuaW1wb3J0IHsgRXZlbnRNYXAgfSBmcm9tICcuLi9tb2RlbHMvZXZlbnRUeXBlLnRzJztcbmltcG9ydCB7IEV2ZW50U2NoZW1hVHlwZSwgRXZlbnRUeXBlIH0gZnJvbSAnLi4vZXZlbnRzU2NoZW1hLnRzJztcbmltcG9ydCB7IHNlbmRUb0RvYmJ5IH0gZnJvbSAnLi4vLi4vdXRpbHMvc2VuZFRvRG9iYnkudHMnO1xuaW1wb3J0IHsgc2F2ZUV2ZW50VG9EeW5hbW9EQiB9IGZyb20gJy4uLy4uL3V0aWxzL3NhdmVFdmVudC50cyc7XG5cbi8qKlxuICogVW5pdHMgZmllbGQgc3BlY2lmaWNhdGlvbjpcbiAqIDB4MDAgLSAxIHdhdHQtaG91ciAoV2gpXG4gKiAweDAxIC0gMTAgV2hcbiAqIDB4MDIgLSAxMDAgV2hcbiAqIDB4MDMgLSAxMDAwIFdoICgxIGtXaClcbiAqIDB4MDQgdG8gMHhGRSAtIFJlc2VydmVkIGZvciBmdXR1cmUgdXNlIC0gRG8gbm90IHVzZVxuICogMHhGRiAtIFVzZWQgaW4gcmVzcG9uc2UgdG8gR2V0QWR2YW5jZWRMb2FkVXAsIGluZGljYXRlcyBhZHZhbmNlZCBsb2FkIHVwIGlzIG5vdCBhY3RpdmVcbiAqIFxuICogVmFsdWUgZmllbGQgc3BlY2lmaWNhdGlvbjpcbiAqIDB4MDAwMCAtIE5vIEVmZmVjdCBvbiB0aGUgU0dELCBidXQgdGhlIFNHRCBzaG91bGQgcmVzcG9uZCB3aXRoIFJlc3BvbnNlIENvZGUgPSBTdWNjZXNzIGlmIHRoaXNcbiAqICAgICAgICAgIEFkdmFuY2VkIExvYWQgVXAgY29tbWFuZCBpcyBpbXBsZW1lbnRlZCBhbmQgdGhlIG5lY2Vzc2FyeSBtaXhpbmcgdmFsdmUgb3Igb3RoZXIgc2FmZXR5XG4gKiAgICAgICAgICBwcmVjYXV0aW9ucyBhcmUgaW4gcGxhY2UuIFdoZW4gdXNpbmcgdGhpcyB2YWx1ZSwgdW5pdHMgbXVzdCBiZSBzZXQgdG8gMHhGRi5cbiAqIDB4MDAwMSB0byAweEZGRkUgLSBUaGlzIHF1YW50aXR5IG9mIFVuaXRzIHNwZWNpZmllcyB0aGUgbWluaW11bSBhbW91bnQgb2YgZW5lcmd5IHRoYXQgdGhlIFNHRFxuICogICAgICAgICAgICAgICAgICAgIHNob3VsZCBzdG9yZSBhYm92ZSB0aGUgYW1vdW50IHRoYXQgd291bGQgYmUgc3RvcmVkIGR1cmluZyBub3JtYWwgb3BlcmF0aW9uLlxuICogMHhGRkZGIC0gU3RvcmUgYXMgbXVjaCBlbmVyZ3kgYXMgcG9zc2libGUgYWJvdmUgdGhlIG5vcm1hbCBhbW91bnQsIHdoaWxlIG1haW50YWluaW5nIHRoZSBzYWZldHlcbiAqICAgICAgICAgIGFuZCBlZmZpY2llbmN5IG9mIHRoZSBTR0QgYW5kIGFueSB0ZW1wZXJhdHVyZSBsaW1pdGluZyBkZXZpY2UuXG4gKi9cbmV4cG9ydCBjb25zdCBoYW5kbGVBZHZhbmNlZExvYWRVcCA9IGFzeW5jIChcbiAgICBkZXZpY2VJZDogc3RyaW5nLFxuICAgIHN0YXJ0VGltZTogRGF0ZSxcbiAgICBkdXJhdGlvbjogbnVtYmVyLFxuICAgIHZhbHVlOiBudW1iZXIsXG4gICAgdW5pdHM6IG51bWJlcixcbiAgICBzdWdnZXN0ZWRMb2FkVXBFZmZpY2llbmN5OiBudW1iZXIsXG4gICAgZXZlbnRJZDogc3RyaW5nLFxuICAgIHN0YXJ0UmFuZG9taXphdGlvbjogbnVtYmVyLFxuICAgIGVuZFJhbmRvbWl6YXRpb246IG51bWJlclxuKTogUHJvbWlzZTxFdmVudFNjaGVtYVR5cGUgfCBudWxsPiA9PiB7XG4gICAgdHJ5IHtcbiAgICAgICAgLy8gVmFsaWRhdGUgdW5pdHNcbiAgICAgICAgaWYgKHVuaXRzIDwgMCB8fCB1bml0cyA+IDB4RkYpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCB1bml0cyB2YWx1ZS4gTXVzdCBiZSBiZXR3ZWVuIDB4MDAgYW5kIDB4RkYnKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodW5pdHMgPj0gMHgwNCAmJiB1bml0cyA8PSAweEZFKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1VuaXRzIHZhbHVlIGlzIGluIHJlc2VydmVkIHJhbmdlICgweDA0IHRvIDB4RkUpJyk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBWYWxpZGF0ZSB2YWx1ZVxuICAgICAgICBpZiAodmFsdWUgPCAwIHx8IHZhbHVlID4gMHhGRkZGKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgdmFsdWUuIE11c3QgYmUgYmV0d2VlbiAweDAwMDAgYW5kIDB4RkZGRicpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gVmFsaWRhdGUgdmFsdWUgYW5kIHVuaXRzIGNvbWJpbmF0aW9uXG4gICAgICAgIGlmICh2YWx1ZSA9PT0gMHgwMDAwICYmIHVuaXRzICE9PSAweEZGKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1doZW4gdmFsdWUgaXMgMHgwMDAwLCB1bml0cyBtdXN0IGJlIHNldCB0byAweEZGJyk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBDb252ZXJ0IHN0YXJ0IHRpbWUgdG8gVVRDIHNlY29uZHMgc2luY2UgMS8xLzIwMDBcbiAgICAgICAgY29uc3Qgc3RhcnRUaW1lVVRDID0gTWF0aC5mbG9vcigoc3RhcnRUaW1lLmdldFRpbWUoKSAtIG5ldyBEYXRlKCcyMDAwLTAxLTAxJykuZ2V0VGltZSgpKSAvIDEwMDApO1xuXG4gICAgICAgIC8vIENyZWF0ZSB0aGUgbWVzc2FnZSBwYXlsb2FkIGFjY29yZGluZyB0byB0aGUgc3BlY1xuICAgICAgICBjb25zdCBidWZmZXIgPSBuZXcgQXJyYXlCdWZmZXIoMTcpO1xuICAgICAgICBjb25zdCB2aWV3ID0gbmV3IERhdGFWaWV3KGJ1ZmZlcik7XG4gICAgICAgIFxuICAgICAgICAvLyBDb21tYW5kIFR5cGVcbiAgICAgICAgdmlldy5zZXRVaW50OCgwLCBFdmVudE1hcC5TRVRfQURWQU5DRURfTE9BRF9VUCk7XG4gICAgICAgIFxuICAgICAgICAvLyBFdmVudCBEdXJhdGlvbiBpbiBNaW51dGVzICgyIGJ5dGVzKVxuICAgICAgICB2aWV3LnNldFVpbnQxNigxLCBkdXJhdGlvbiwgdHJ1ZSk7XG4gICAgICAgIFxuICAgICAgICAvLyBWYWx1ZSAoMiBieXRlcylcbiAgICAgICAgdmlldy5zZXRVaW50MTYoMywgdmFsdWUsIHRydWUpO1xuICAgICAgICBcbiAgICAgICAgLy8gVW5pdHNcbiAgICAgICAgdmlldy5zZXRVaW50OCg1LCB1bml0cywgdHJ1ZSk7XG4gICAgICAgIFxuICAgICAgICAvLyBTdWdnZXN0ZWQgTG9hZCBVcCBFZmZpY2llbmN5XG4gICAgICAgIHZpZXcuc2V0VWludDgoNiwgc3VnZ2VzdGVkTG9hZFVwRWZmaWNpZW5jeSk7XG4gICAgICAgIFxuICAgICAgICAvLyBFdmVudCBJRCAoNCBieXRlcylcbiAgICAgICAgY29uc3QgZXZlbnRJZE51bSA9IHBhcnNlSW50KGV2ZW50SWQucmVwbGFjZSgvLS9nLCAnJykuc3Vic3RyaW5nKDAsIDgpLCAxNik7XG4gICAgICAgIHZpZXcuc2V0VWludDMyKDcsIGV2ZW50SWROdW0sIHRydWUpO1xuICAgICAgICBcbiAgICAgICAgLy8gU3RhcnQgVGltZSBVVEMgKDQgYnl0ZXMpXG4gICAgICAgIHZpZXcuc2V0VWludDMyKDExLCBzdGFydFRpbWVVVEMsIHRydWUpO1xuICAgICAgICBcbiAgICAgICAgLy8gU3RhcnQgUmFuZG9taXphdGlvblxuICAgICAgICB2aWV3LnNldFVpbnQ4KDE1LCBzdGFydFJhbmRvbWl6YXRpb24pO1xuICAgICAgICBcbiAgICAgICAgLy8gRW5kIFJhbmRvbWl6YXRpb25cbiAgICAgICAgdmlldy5zZXRVaW50OCgxNiwgZW5kUmFuZG9taXphdGlvbik7XG5cbiAgICAgICAgLy8gU2VuZCB0aGUgbWVzc2FnZSB0byBEb2JieVxuICAgICAgICBjb25zdCBzZW50VG9Eb2JieSA9IGF3YWl0IHNlbmRUb0RvYmJ5KGRldmljZUlkLCBidWZmZXIpO1xuXG4gICAgICAgIC8vIENyZWF0ZSB0aGUgZXZlbnQgcmVjb3JkXG4gICAgICAgIGNvbnN0IGV2ZW50OiBFdmVudFNjaGVtYVR5cGUgPSB7XG4gICAgICAgICAgICBldmVudF9pZDogdXVpZHY0KCksXG4gICAgICAgICAgICBldmVudF90eXBlOiBFdmVudFR5cGUuQURWQU5DRURfTE9BRF9VUCxcbiAgICAgICAgICAgIGV2ZW50X2RhdGE6IHtcbiAgICAgICAgICAgICAgICBkZXZpY2VfaWQ6IGRldmljZUlkLFxuICAgICAgICAgICAgICAgIHN0YXJ0X3RpbWU6IHN0YXJ0VGltZS50b0lTT1N0cmluZygpLFxuICAgICAgICAgICAgICAgIGR1cmF0aW9uLFxuICAgICAgICAgICAgICAgIHZhbHVlLFxuICAgICAgICAgICAgICAgIHVuaXRzLFxuICAgICAgICAgICAgICAgIHN1Z2dlc3RlZF9sb2FkX3VwX2VmZmljaWVuY3k6IHN1Z2dlc3RlZExvYWRVcEVmZmljaWVuY3ksXG4gICAgICAgICAgICAgICAgZXZlbnRfaWQ6IGV2ZW50SWQsXG4gICAgICAgICAgICAgICAgc3RhcnRfcmFuZG9taXphdGlvbjogc3RhcnRSYW5kb21pemF0aW9uLFxuICAgICAgICAgICAgICAgIGVuZF9yYW5kb21pemF0aW9uOiBlbmRSYW5kb21pemF0aW9uLFxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IEFycmF5LmZyb20obmV3IFVpbnQ4QXJyYXkoYnVmZmVyKSksXG4gICAgICAgICAgICAgICAgZXZlbnRfc2VudDogc2VudFRvRG9iYnlcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICAvLyBTYXZlIHRoZSBldmVudCB0byBEeW5hbW9EQlxuICAgICAgICBhd2FpdCBzYXZlRXZlbnRUb0R5bmFtb0RCKGV2ZW50KTtcblxuICAgICAgICByZXR1cm4gZXZlbnQ7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGhhbmRsaW5nIGFkdmFuY2VkIGxvYWQgdXAgZXZlbnQ6XCIsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufTsgIl19