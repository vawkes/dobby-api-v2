import { EventSchemaType } from "../eventsSchema.ts";
interface SetUtcTimeData {
    device_id: string;
    utc_seconds: number;
    utc_offset: number;
    dst_offset: number;
    event_sent?: boolean;
}
export declare const handleSetUtcTime: (eventData: SetUtcTimeData) => Promise<EventSchemaType>;
export {};
