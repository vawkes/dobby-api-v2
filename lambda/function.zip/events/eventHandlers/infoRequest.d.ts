import { EventSchemaType } from "../eventsSchema";
declare const handleInfoRequest: (device_id: string, timestamp?: Date) => Promise<EventSchemaType>;
export { handleInfoRequest };
