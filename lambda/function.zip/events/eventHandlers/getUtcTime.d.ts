import { EventSchemaType } from "../eventsSchema.ts";
interface GetUtcTimeData {
    device_id: string;
    event_sent?: boolean;
}
export declare const handleGetUtcTime: (eventData: GetUtcTimeData) => Promise<EventSchemaType>;
export {};
