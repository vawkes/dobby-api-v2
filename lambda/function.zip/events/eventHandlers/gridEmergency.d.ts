import { EventSchemaType } from "../eventsSchema";
declare const handleGridEmergency: (device_id: string, startTime?: Date) => Promise<EventSchemaType>;
export { handleGridEmergency };
