import { EventSchemaType } from "../eventsSchema.ts";
interface RequestConnectionInfoData {
    device_id: string;
    event_sent?: boolean;
}
export declare const handleRequestConnectionInfo: (eventData: RequestConnectionInfoData) => Promise<EventSchemaType>;
export {};
