import { EventSchemaType } from "../eventsSchema";
declare const handleLoadUp: (device_id: string, startTime?: Date, eventDurationSeconds?: number) => Promise<EventSchemaType>;
export { handleLoadUp };
