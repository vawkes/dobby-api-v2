import { EventSchemaType } from "../eventsSchema";
declare const handleStartShed: (device_id: string, startTime?: Date, duration?: number) => Promise<EventSchemaType>;
export { handleStartShed };
