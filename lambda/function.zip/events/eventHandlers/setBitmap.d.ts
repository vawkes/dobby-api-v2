import { EventSchemaType } from "../eventsSchema.ts";
interface SetBitmapData {
    device_id: string;
    bit_number: number;
    set_value: boolean;
    event_sent?: boolean;
}
export declare const handleSetBitmap: (eventData: SetBitmapData) => Promise<EventSchemaType>;
export {};
