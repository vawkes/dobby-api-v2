import { EventSchemaType } from "../eventsSchema";
export declare function handleCustomerOverride(deviceId: string, override: boolean): Promise<EventSchemaType>;
