import { EventSchemaType } from '../eventsSchema.ts';
/**
 * Units field specification:
 * 0x00 - 1 watt-hour (Wh)
 * 0x01 - 10 Wh
 * 0x02 - 100 Wh
 * 0x03 - 1000 Wh (1 kWh)
 * 0x04 to 0xFE - Reserved for future use - Do not use
 * 0xFF - Used in response to GetAdvancedLoadUp, indicates advanced load up is not active
 *
 * Value field specification:
 * 0x0000 - No Effect on the SGD, but the SGD should respond with Response Code = Success if this
 *          Advanced Load Up command is implemented and the necessary mixing valve or other safety
 *          precautions are in place. When using this value, units must be set to 0xFF.
 * 0x0001 to 0xFFFE - This quantity of Units specifies the minimum amount of energy that the SGD
 *                    should store above the amount that would be stored during normal operation.
 * 0xFFFF - Store as much energy as possible above the normal amount, while maintaining the safety
 *          and efficiency of the SGD and any temperature limiting device.
 */
export declare const handleAdvancedLoadUp: (deviceId: string, startTime: Date, duration: number, value: number, units: number, suggestedLoadUpEfficiency: number, eventId: string, startRandomization: number, endRandomization: number) => Promise<EventSchemaType | null>;
