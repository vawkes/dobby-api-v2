import { z } from '@hono/zod-openapi';
declare enum EventType {
    LOAD_UP = "LOAD_UP",
    GRID_EMERGENCY = "GRID_EMERGENCY",
    CRITICAL_PEAK = "CRITICAL_PEAK",
    START_SHED = "START_SHED",
    END_SHED = "END_SHED",
    INFO_REQUEST = "INFO_REQUEST",
    ADVANCED_LOAD_UP = "ADVANCED_LOAD_UP",
    CUSTOMER_OVERRIDE = "CUSTOMER_OVERRIDE",
    SET_UTC_TIME = "SET_UTC_TIME",
    GET_UTC_TIME = "GET_UTC_TIME",
    SET_BITMAP = "SET_BITMAP",
    REQUEST_CONNECTION_INFO = "REQUEST_CONNECTION_INFO"
}
declare const eventRequestSchema: z.ZodDiscriminatedUnion<"event_type", [z.ZodObject<{
    event_id: z.ZodString;
    event_type: z.ZodLiteral<EventType.LOAD_UP>;
    event_data: z.ZodObject<{
        device_id: z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>;
        start_time: z.ZodString;
        duration: z.ZodOptional<z.ZodNumber>;
        event_sent: z.ZodOptional<z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        device_id: string | string[];
        start_time: string;
        duration?: number | undefined;
        event_sent?: boolean | undefined;
    }, {
        device_id: string | string[];
        start_time: string;
        duration?: number | undefined;
        event_sent?: boolean | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    event_id: string;
    event_type: EventType.LOAD_UP;
    event_data: {
        device_id: string | string[];
        start_time: string;
        duration?: number | undefined;
        event_sent?: boolean | undefined;
    };
}, {
    event_id: string;
    event_type: EventType.LOAD_UP;
    event_data: {
        device_id: string | string[];
        start_time: string;
        duration?: number | undefined;
        event_sent?: boolean | undefined;
    };
}>, z.ZodObject<{
    event_id: z.ZodString;
    event_type: z.ZodLiteral<EventType.GRID_EMERGENCY>;
    event_data: z.ZodObject<{
        device_id: z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>;
        start_time: z.ZodString;
        event_sent: z.ZodOptional<z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        device_id: string | string[];
        start_time: string;
        event_sent?: boolean | undefined;
    }, {
        device_id: string | string[];
        start_time: string;
        event_sent?: boolean | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    event_id: string;
    event_type: EventType.GRID_EMERGENCY;
    event_data: {
        device_id: string | string[];
        start_time: string;
        event_sent?: boolean | undefined;
    };
}, {
    event_id: string;
    event_type: EventType.GRID_EMERGENCY;
    event_data: {
        device_id: string | string[];
        start_time: string;
        event_sent?: boolean | undefined;
    };
}>, z.ZodObject<{
    event_id: z.ZodString;
    event_type: z.ZodLiteral<EventType.CRITICAL_PEAK>;
    event_data: z.ZodObject<{
        device_id: z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>;
        start_time: z.ZodString;
        event_sent: z.ZodOptional<z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        device_id: string | string[];
        start_time: string;
        event_sent?: boolean | undefined;
    }, {
        device_id: string | string[];
        start_time: string;
        event_sent?: boolean | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    event_id: string;
    event_type: EventType.CRITICAL_PEAK;
    event_data: {
        device_id: string | string[];
        start_time: string;
        event_sent?: boolean | undefined;
    };
}, {
    event_id: string;
    event_type: EventType.CRITICAL_PEAK;
    event_data: {
        device_id: string | string[];
        start_time: string;
        event_sent?: boolean | undefined;
    };
}>, z.ZodObject<{
    event_id: z.ZodString;
    event_type: z.ZodLiteral<EventType.START_SHED>;
    event_data: z.ZodObject<{
        device_id: z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>;
        start_time: z.ZodString;
        duration: z.ZodOptional<z.ZodNumber>;
        event_sent: z.ZodOptional<z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        device_id: string | string[];
        start_time: string;
        duration?: number | undefined;
        event_sent?: boolean | undefined;
    }, {
        device_id: string | string[];
        start_time: string;
        duration?: number | undefined;
        event_sent?: boolean | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    event_id: string;
    event_type: EventType.START_SHED;
    event_data: {
        device_id: string | string[];
        start_time: string;
        duration?: number | undefined;
        event_sent?: boolean | undefined;
    };
}, {
    event_id: string;
    event_type: EventType.START_SHED;
    event_data: {
        device_id: string | string[];
        start_time: string;
        duration?: number | undefined;
        event_sent?: boolean | undefined;
    };
}>, z.ZodObject<{
    event_id: z.ZodString;
    event_type: z.ZodLiteral<EventType.END_SHED>;
    event_data: z.ZodObject<{
        device_id: z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>;
        start_time: z.ZodOptional<z.ZodString>;
        event_sent: z.ZodOptional<z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        device_id: string | string[];
        start_time?: string | undefined;
        event_sent?: boolean | undefined;
    }, {
        device_id: string | string[];
        start_time?: string | undefined;
        event_sent?: boolean | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    event_id: string;
    event_type: EventType.END_SHED;
    event_data: {
        device_id: string | string[];
        start_time?: string | undefined;
        event_sent?: boolean | undefined;
    };
}, {
    event_id: string;
    event_type: EventType.END_SHED;
    event_data: {
        device_id: string | string[];
        start_time?: string | undefined;
        event_sent?: boolean | undefined;
    };
}>, z.ZodObject<{
    event_id: z.ZodString;
    event_type: z.ZodLiteral<EventType.INFO_REQUEST>;
    event_data: z.ZodObject<{
        device_id: z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>;
        timestamp: z.ZodOptional<z.ZodString>;
        event_sent: z.ZodOptional<z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        device_id: string | string[];
        timestamp?: string | undefined;
        event_sent?: boolean | undefined;
    }, {
        device_id: string | string[];
        timestamp?: string | undefined;
        event_sent?: boolean | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    event_id: string;
    event_type: EventType.INFO_REQUEST;
    event_data: {
        device_id: string | string[];
        timestamp?: string | undefined;
        event_sent?: boolean | undefined;
    };
}, {
    event_id: string;
    event_type: EventType.INFO_REQUEST;
    event_data: {
        device_id: string | string[];
        timestamp?: string | undefined;
        event_sent?: boolean | undefined;
    };
}>, z.ZodObject<{
    event_id: z.ZodString;
    event_type: z.ZodLiteral<EventType.ADVANCED_LOAD_UP>;
    event_data: z.ZodObject<{
        device_id: z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>;
        start_time: z.ZodString;
        duration: z.ZodNumber;
        value: z.ZodNumber;
        units: z.ZodNumber;
        suggested_load_up_efficiency: z.ZodNumber;
        event_id: z.ZodString;
        start_randomization: z.ZodNumber;
        end_randomization: z.ZodNumber;
        event_sent: z.ZodOptional<z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        value: number;
        device_id: string | string[];
        event_id: string;
        duration: number;
        start_time: string;
        units: number;
        suggested_load_up_efficiency: number;
        start_randomization: number;
        end_randomization: number;
        event_sent?: boolean | undefined;
    }, {
        value: number;
        device_id: string | string[];
        event_id: string;
        duration: number;
        start_time: string;
        units: number;
        suggested_load_up_efficiency: number;
        start_randomization: number;
        end_randomization: number;
        event_sent?: boolean | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    event_id: string;
    event_type: EventType.ADVANCED_LOAD_UP;
    event_data: {
        value: number;
        device_id: string | string[];
        event_id: string;
        duration: number;
        start_time: string;
        units: number;
        suggested_load_up_efficiency: number;
        start_randomization: number;
        end_randomization: number;
        event_sent?: boolean | undefined;
    };
}, {
    event_id: string;
    event_type: EventType.ADVANCED_LOAD_UP;
    event_data: {
        value: number;
        device_id: string | string[];
        event_id: string;
        duration: number;
        start_time: string;
        units: number;
        suggested_load_up_efficiency: number;
        start_randomization: number;
        end_randomization: number;
        event_sent?: boolean | undefined;
    };
}>, z.ZodObject<{
    event_id: z.ZodString;
    event_type: z.ZodLiteral<EventType.CUSTOMER_OVERRIDE>;
    event_data: z.ZodObject<{
        device_id: z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>;
        override: z.ZodBoolean;
        event_sent: z.ZodOptional<z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        device_id: string | string[];
        override: boolean;
        event_sent?: boolean | undefined;
    }, {
        device_id: string | string[];
        override: boolean;
        event_sent?: boolean | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    event_id: string;
    event_type: EventType.CUSTOMER_OVERRIDE;
    event_data: {
        device_id: string | string[];
        override: boolean;
        event_sent?: boolean | undefined;
    };
}, {
    event_id: string;
    event_type: EventType.CUSTOMER_OVERRIDE;
    event_data: {
        device_id: string | string[];
        override: boolean;
        event_sent?: boolean | undefined;
    };
}>, z.ZodObject<{
    event_id: z.ZodString;
    event_type: z.ZodLiteral<EventType.SET_UTC_TIME>;
    event_data: z.ZodObject<{
        device_id: z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>;
        utc_seconds: z.ZodNumber;
        utc_offset: z.ZodNumber;
        dst_offset: z.ZodNumber;
        event_sent: z.ZodOptional<z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        device_id: string | string[];
        utc_seconds: number;
        utc_offset: number;
        dst_offset: number;
        event_sent?: boolean | undefined;
    }, {
        device_id: string | string[];
        utc_seconds: number;
        utc_offset: number;
        dst_offset: number;
        event_sent?: boolean | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    event_id: string;
    event_type: EventType.SET_UTC_TIME;
    event_data: {
        device_id: string | string[];
        utc_seconds: number;
        utc_offset: number;
        dst_offset: number;
        event_sent?: boolean | undefined;
    };
}, {
    event_id: string;
    event_type: EventType.SET_UTC_TIME;
    event_data: {
        device_id: string | string[];
        utc_seconds: number;
        utc_offset: number;
        dst_offset: number;
        event_sent?: boolean | undefined;
    };
}>, z.ZodObject<{
    event_id: z.ZodString;
    event_type: z.ZodLiteral<EventType.GET_UTC_TIME>;
    event_data: z.ZodObject<{
        device_id: z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>;
        event_sent: z.ZodOptional<z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        device_id: string | string[];
        event_sent?: boolean | undefined;
    }, {
        device_id: string | string[];
        event_sent?: boolean | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    event_id: string;
    event_type: EventType.GET_UTC_TIME;
    event_data: {
        device_id: string | string[];
        event_sent?: boolean | undefined;
    };
}, {
    event_id: string;
    event_type: EventType.GET_UTC_TIME;
    event_data: {
        device_id: string | string[];
        event_sent?: boolean | undefined;
    };
}>, z.ZodObject<{
    event_id: z.ZodString;
    event_type: z.ZodLiteral<EventType.SET_BITMAP>;
    event_data: z.ZodObject<{
        device_id: z.ZodString;
        bit_number: z.ZodNumber;
        set_value: z.ZodBoolean;
        event_sent: z.ZodOptional<z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        device_id: string;
        bit_number: number;
        set_value: boolean;
        event_sent?: boolean | undefined;
    }, {
        device_id: string;
        bit_number: number;
        set_value: boolean;
        event_sent?: boolean | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    event_id: string;
    event_type: EventType.SET_BITMAP;
    event_data: {
        device_id: string;
        bit_number: number;
        set_value: boolean;
        event_sent?: boolean | undefined;
    };
}, {
    event_id: string;
    event_type: EventType.SET_BITMAP;
    event_data: {
        device_id: string;
        bit_number: number;
        set_value: boolean;
        event_sent?: boolean | undefined;
    };
}>, z.ZodObject<{
    event_id: z.ZodString;
    event_type: z.ZodLiteral<EventType.REQUEST_CONNECTION_INFO>;
    event_data: z.ZodObject<{
        device_id: z.ZodUnion<[z.ZodString, z.ZodArray<z.ZodString, "many">]>;
        event_sent: z.ZodOptional<z.ZodBoolean>;
        last_rx_rssi: z.ZodOptional<z.ZodNumber>;
        last_rx_snr: z.ZodOptional<z.ZodNumber>;
        last_rx_link_type: z.ZodOptional<z.ZodNumber>;
    }, "strip", z.ZodTypeAny, {
        device_id: string | string[];
        last_rx_rssi?: number | undefined;
        event_sent?: boolean | undefined;
        last_rx_snr?: number | undefined;
        last_rx_link_type?: number | undefined;
    }, {
        device_id: string | string[];
        last_rx_rssi?: number | undefined;
        event_sent?: boolean | undefined;
        last_rx_snr?: number | undefined;
        last_rx_link_type?: number | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    event_id: string;
    event_type: EventType.REQUEST_CONNECTION_INFO;
    event_data: {
        device_id: string | string[];
        last_rx_rssi?: number | undefined;
        event_sent?: boolean | undefined;
        last_rx_snr?: number | undefined;
        last_rx_link_type?: number | undefined;
    };
}, {
    event_id: string;
    event_type: EventType.REQUEST_CONNECTION_INFO;
    event_data: {
        device_id: string | string[];
        last_rx_rssi?: number | undefined;
        event_sent?: boolean | undefined;
        last_rx_snr?: number | undefined;
        last_rx_link_type?: number | undefined;
    };
}>]>;
declare const eventSchema: z.ZodObject<{
    event_id: z.ZodString;
    event_type: z.ZodNativeEnum<typeof EventType>;
    event_data: z.ZodObject<{}, "passthrough", z.ZodTypeAny, z.objectOutputType<{}, z.ZodTypeAny, "passthrough">, z.objectInputType<{}, z.ZodTypeAny, "passthrough">>;
    event_ack: z.ZodNullable<z.ZodOptional<z.ZodBoolean>>;
}, "strip", z.ZodTypeAny, {
    event_id: string;
    event_type: EventType;
    event_data: {} & {
        [k: string]: unknown;
    };
    event_ack?: boolean | null | undefined;
}, {
    event_id: string;
    event_type: EventType;
    event_data: {} & {
        [k: string]: unknown;
    };
    event_ack?: boolean | null | undefined;
}>;
declare const eventsSchema: z.ZodArray<z.ZodObject<{
    event_id: z.ZodString;
    event_type: z.ZodNativeEnum<typeof EventType>;
    event_data: z.ZodObject<{}, "passthrough", z.ZodTypeAny, z.objectOutputType<{}, z.ZodTypeAny, "passthrough">, z.objectInputType<{}, z.ZodTypeAny, "passthrough">>;
    event_ack: z.ZodNullable<z.ZodOptional<z.ZodBoolean>>;
}, "strip", z.ZodTypeAny, {
    event_id: string;
    event_type: EventType;
    event_data: {} & {
        [k: string]: unknown;
    };
    event_ack?: boolean | null | undefined;
}, {
    event_id: string;
    event_type: EventType;
    event_data: {} & {
        [k: string]: unknown;
    };
    event_ack?: boolean | null | undefined;
}>, "many">;
declare const bulkResponseSchema: z.ZodObject<{
    successful_events: z.ZodArray<z.ZodObject<{
        event_id: z.ZodString;
        event_type: z.ZodNativeEnum<typeof EventType>;
        event_data: z.ZodObject<{}, "passthrough", z.ZodTypeAny, z.objectOutputType<{}, z.ZodTypeAny, "passthrough">, z.objectInputType<{}, z.ZodTypeAny, "passthrough">>;
        event_ack: z.ZodNullable<z.ZodOptional<z.ZodBoolean>>;
    }, "strip", z.ZodTypeAny, {
        event_id: string;
        event_type: EventType;
        event_data: {} & {
            [k: string]: unknown;
        };
        event_ack?: boolean | null | undefined;
    }, {
        event_id: string;
        event_type: EventType;
        event_data: {} & {
            [k: string]: unknown;
        };
        event_ack?: boolean | null | undefined;
    }>, "many">;
    failed_events: z.ZodOptional<z.ZodArray<z.ZodObject<{
        device_id: z.ZodString;
        error: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        error: string;
        device_id: string;
    }, {
        error: string;
        device_id: string;
    }>, "many">>;
}, "strip", z.ZodTypeAny, {
    successful_events: {
        event_id: string;
        event_type: EventType;
        event_data: {} & {
            [k: string]: unknown;
        };
        event_ack?: boolean | null | undefined;
    }[];
    failed_events?: {
        error: string;
        device_id: string;
    }[] | undefined;
}, {
    successful_events: {
        event_id: string;
        event_type: EventType;
        event_data: {} & {
            [k: string]: unknown;
        };
        event_ack?: boolean | null | undefined;
    }[];
    failed_events?: {
        error: string;
        device_id: string;
    }[] | undefined;
}>;
type EventSchemaType = z.infer<typeof eventSchema>;
export { eventsSchema, eventSchema, eventRequestSchema, bulkResponseSchema, EventType, EventSchemaType };
