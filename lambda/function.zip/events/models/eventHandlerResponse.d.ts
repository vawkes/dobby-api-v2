export interface EventHandlerResponse {
    success: boolean;
    sentToDobby: boolean;
}
