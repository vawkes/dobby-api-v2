"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const hono_1 = require("hono");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const util_dynamodb_1 = require("@aws-sdk/util-dynamodb");
const eventsSchema_ts_1 = require("./eventsSchema.ts");
const hono_openapi_1 = require("hono-openapi");
const zod_1 = require("hono-openapi/zod");
const loadUp_ts_1 = require("./eventHandlers/loadUp.ts");
const startShed_ts_1 = require("./eventHandlers/startShed.ts");
const endShed_ts_1 = require("./eventHandlers/endShed.ts");
const gridEmergency_ts_1 = require("./eventHandlers/gridEmergency.ts");
const criticalPeak_ts_1 = require("./eventHandlers/criticalPeak.ts");
const infoRequest_ts_1 = require("./eventHandlers/infoRequest.ts");
const advancedLoadUp_ts_1 = require("./eventHandlers/advancedLoadUp.ts");
const customerOverride_ts_1 = require("./eventHandlers/customerOverride.ts");
const setUtcTime_ts_1 = require("./eventHandlers/setUtcTime.ts");
const getUtcTime_ts_1 = require("./eventHandlers/getUtcTime.ts");
const setBitmap_ts_1 = require("./eventHandlers/setBitmap.ts");
const requestConnectionInfo_ts_1 = require("./eventHandlers/requestConnectionInfo.ts");
const uuid_1 = require("uuid");
const app = new hono_1.Hono();
app.get("/", (0, hono_openapi_1.describeRoute)({
    description: "Fetch all events",
    responses: {
        200: {
            description: "Retrieve List of Events",
            content: {
                'application/json': {
                    schema: (0, zod_1.resolver)(eventsSchema_ts_1.eventsSchema),
                },
            },
        },
        500: {
            description: "Internal Server Error",
        },
    },
}), async (c) => {
    try {
        const dynamodb = new client_dynamodb_1.DynamoDB({ "region": "us-east-1" });
        const results = await dynamodb.scan({ TableName: "DobbyEvent" });
        // Transform the data to ensure it matches the schema
        const events = results.Items?.map(item => {
            const event = (0, util_dynamodb_1.unmarshall)(item);
            // Make sure event_data exists and has the necessary structure
            if (!event.event_data) {
                event.event_data = {
                    device_id: event.device_id || ''
                };
                // Add appropriate fields based on event type
                if (event.event_type === eventsSchema_ts_1.EventType.INFO_REQUEST) {
                    event.event_data.timestamp = event.timestamp || new Date().toISOString();
                }
                else if (['LOAD_UP', 'GRID_EMERGENCY', 'CRITICAL_PEAK', 'START_SHED', 'END_SHED', 'CUSTOMER_OVERRIDE'].includes(event.event_type)) {
                    event.event_data.start_time = event.start_time || new Date().toISOString();
                    // Add duration for event types that need it
                    if (['LOAD_UP', 'START_SHED'].includes(event.event_type)) {
                        event.event_data.duration = event.duration || 0;
                    }
                }
            }
            // Copy event_ack directly to the top level of the event
            if (event.event_ack !== undefined) {
                event.event_ack = event.event_ack;
            }
            else {
                event.event_ack = false;
            }
            return event;
        }) || [];
        return c.json(eventsSchema_ts_1.eventsSchema.parse(events));
    }
    catch (error) {
        console.error("Error fetching events:", error);
        return c.json({ error: "Failed to fetch events" }, 500);
    }
});
app.get("/device/:deviceId", (0, hono_openapi_1.describeRoute)({
    description: "Fetch events for a specific device",
    responses: {
        200: {
            description: "Retrieve events for a device",
            content: {
                'application/json': {
                    schema: (0, zod_1.resolver)(eventsSchema_ts_1.eventsSchema),
                },
            },
        },
        404: {
            description: "No events found for this device",
        },
        500: {
            description: "Internal Server Error",
        },
    },
}), async (c) => {
    try {
        const deviceId = c.req.param("deviceId");
        const dynamodb = new client_dynamodb_1.DynamoDB({ "region": "us-east-1" });
        // Query the GSI (device_id)
        const queryParams = {
            TableName: "DobbyEvent",
            IndexName: "device_id-index",
            KeyConditionExpression: "device_id = :deviceId",
            ExpressionAttributeValues: {
                ":deviceId": { S: deviceId }
            }
        };
        const results = await dynamodb.query(queryParams);
        if (!results.Items || results.Items.length === 0) {
            return c.json({ error: "No events found for this device" }, 404);
        }
        // Transform the data to ensure it matches the schema
        const events = results.Items.map(item => {
            const event = (0, util_dynamodb_1.unmarshall)(item);
            // Make sure event_data exists and has the necessary structure
            if (!event.event_data) {
                event.event_data = {
                    device_id: event.device_id || deviceId
                };
                // Add appropriate fields based on event type
                if (event.event_type === eventsSchema_ts_1.EventType.INFO_REQUEST) {
                    event.event_data.timestamp = event.timestamp || new Date().toISOString();
                }
                else if (['LOAD_UP', 'GRID_EMERGENCY', 'CRITICAL_PEAK', 'START_SHED', 'END_SHED', 'CUSTOMER_OVERRIDE'].includes(event.event_type)) {
                    event.event_data.start_time = event.start_time || new Date().toISOString();
                    // Add duration for event types that need it
                    if (['LOAD_UP', 'START_SHED'].includes(event.event_type)) {
                        event.event_data.duration = event.duration || 0;
                    }
                }
            }
            // Copy event_ack directly to the top level of the event 
            // This is for the frontend to have easy access to this field
            if (event.event_ack !== undefined) {
                event.event_ack = event.event_ack;
            }
            else {
                event.event_ack = false;
            }
            return event;
        });
        return c.json(eventsSchema_ts_1.eventsSchema.parse(events));
    }
    catch (error) {
        console.error("Error fetching device events:", error);
        return c.json({ error: "Failed to fetch device events" }, 500);
    }
});
app.get("/:eventId", (0, hono_openapi_1.describeRoute)({
    description: "Fetch single event",
    responses: {
        200: {
            description: "Retrieve a single event",
            content: {
                'application/json': {
                    schema: (0, zod_1.resolver)(eventsSchema_ts_1.eventSchema),
                },
            },
        },
        404: {
            description: "Event not found",
        },
        500: {
            description: "Internal Server Error",
        },
    },
}), async (c) => {
    try {
        const dynamodb = new client_dynamodb_1.DynamoDB({ "region": "us-east-1" });
        const results = await dynamodb.getItem({ TableName: "DobbyEvent", Key: { event_id: { S: c.req.param("eventId") } } });
        if (!results.Item) {
            return c.json({ error: "Event not found" }, 404);
        }
        const event = (0, util_dynamodb_1.unmarshall)(results.Item);
        // Make sure event_data exists and has the necessary structure
        if (!event.event_data) {
            event.event_data = {
                device_id: event.device_id || ''
            };
            // Add appropriate fields based on event type
            if (event.event_type === eventsSchema_ts_1.EventType.INFO_REQUEST) {
                event.event_data.timestamp = event.timestamp || new Date().toISOString();
            }
            else if (['LOAD_UP', 'GRID_EMERGENCY', 'CRITICAL_PEAK', 'START_SHED', 'END_SHED', 'CUSTOMER_OVERRIDE'].includes(event.event_type)) {
                event.event_data.start_time = event.start_time || new Date().toISOString();
                // Add duration for event types that need it
                if (['LOAD_UP', 'START_SHED'].includes(event.event_type)) {
                    event.event_data.duration = event.duration || 0;
                }
            }
        }
        // Copy event_ack directly to the top level of the event
        if (event.event_ack !== undefined) {
            event.event_ack = event.event_ack;
        }
        else {
            event.event_ack = false;
        }
        return c.json(eventsSchema_ts_1.eventSchema.parse(event));
    }
    catch (error) {
        console.error("Error fetching event:", error);
        return c.json({ error: "Failed to fetch event" }, 500);
    }
});
app.post("/", (0, hono_openapi_1.describeRoute)({
    description: "Create event(s) for one or multiple devices",
    responses: {
        200: {
            description: "Event(s) created successfully",
            content: {
                'application/json': {
                    schema: (0, zod_1.resolver)(eventsSchema_ts_1.bulkResponseSchema),
                },
            },
        },
        400: {
            description: "Bad Request",
        },
        500: {
            description: "Internal Server Error",
        },
    },
}), (0, zod_1.validator)('json', eventsSchema_ts_1.eventRequestSchema), async (c) => {
    try {
        const body = await c.req.json();
        const parsedBody = eventsSchema_ts_1.eventRequestSchema.parse(body);
        let result = null;
        const eventType = parsedBody.event_type;
        const eventData = parsedBody.event_data;
        // Handle both single device_id and array of device_ids
        const deviceIds = Array.isArray(eventData.device_id)
            ? eventData.device_id
            : [eventData.device_id];
        // If only one device, handle as single operation
        if (deviceIds.length === 1) {
            const deviceId = deviceIds[0];
            // Create event with appropriate handler based on event type
            if (eventType === eventsSchema_ts_1.EventType.LOAD_UP) {
                result = await (0, loadUp_ts_1.handleLoadUp)(deviceId, 'start_time' in eventData && eventData.start_time ? new Date(eventData.start_time) : undefined, 'duration' in eventData ? eventData.duration : undefined);
            }
            else if (eventType === eventsSchema_ts_1.EventType.GRID_EMERGENCY) {
                result = await (0, gridEmergency_ts_1.handleGridEmergency)(deviceId, 'start_time' in eventData && eventData.start_time ? new Date(eventData.start_time) : undefined);
            }
            else if (eventType === eventsSchema_ts_1.EventType.CRITICAL_PEAK) {
                result = await (0, criticalPeak_ts_1.handleCriticalPeak)(deviceId, 'start_time' in eventData && eventData.start_time ? new Date(eventData.start_time) : undefined);
            }
            else if (eventType === eventsSchema_ts_1.EventType.START_SHED) {
                result = await (0, startShed_ts_1.handleStartShed)(deviceId, 'start_time' in eventData && eventData.start_time ? new Date(eventData.start_time) : undefined, 'duration' in eventData ? eventData.duration || 0 : 0);
            }
            else if (eventType === eventsSchema_ts_1.EventType.END_SHED) {
                result = await (0, endShed_ts_1.handleEndShed)(deviceId, 'start_time' in eventData && eventData.start_time ? new Date(eventData.start_time) : undefined);
            }
            else if (eventType === eventsSchema_ts_1.EventType.INFO_REQUEST) {
                result = await (0, infoRequest_ts_1.handleInfoRequest)(deviceId, 'timestamp' in eventData && eventData.timestamp ? new Date(eventData.timestamp) : undefined);
            }
            else if (eventType === eventsSchema_ts_1.EventType.ADVANCED_LOAD_UP) {
                const startTime = 'start_time' in eventData && eventData.start_time
                    ? new Date(eventData.start_time)
                    : new Date();
                const duration = 'duration' in eventData ? eventData.duration || 0 : 0;
                const value = 'value' in eventData ? eventData.value || 0 : 0;
                const units = 'units' in eventData ? eventData.units || 0 : 0;
                const suggestedLoadUpEfficiency = 'suggested_load_up_efficiency' in eventData ? eventData.suggested_load_up_efficiency || 0 : 0;
                const startRandomization = 'start_randomization' in eventData ? eventData.start_randomization || 0 : 0;
                const endRandomization = 'end_randomization' in eventData ? eventData.end_randomization || 0 : 0;
                result = await (0, advancedLoadUp_ts_1.handleAdvancedLoadUp)(deviceId, startTime, duration, value, units, suggestedLoadUpEfficiency, 'event_id' in eventData ? eventData.event_id : (0, uuid_1.v4)(), startRandomization, endRandomization);
            }
            else if (eventType === eventsSchema_ts_1.EventType.CUSTOMER_OVERRIDE) {
                result = await (0, customerOverride_ts_1.handleCustomerOverride)(deviceId, 'override' in eventData ? eventData.override : false);
            }
            else if (eventType === eventsSchema_ts_1.EventType.SET_UTC_TIME) {
                result = await (0, setUtcTime_ts_1.handleSetUtcTime)(eventData);
            }
            else if (eventType === eventsSchema_ts_1.EventType.GET_UTC_TIME) {
                result = await (0, getUtcTime_ts_1.handleGetUtcTime)(eventData);
            }
            else if (eventType === eventsSchema_ts_1.EventType.SET_BITMAP) {
                result = await (0, setBitmap_ts_1.handleSetBitmap)(eventData);
            }
            else if (eventType === eventsSchema_ts_1.EventType.REQUEST_CONNECTION_INFO) {
                result = await (0, requestConnectionInfo_ts_1.handleRequestConnectionInfo)({
                    device_id: deviceId,
                    event_sent: false
                });
            }
            else {
                // Unsupported event type
                return c.json({
                    statusCode: 400,
                    body: { reason: `Unsupported event type: ${eventType}` }
                }, 400);
            }
            if (!result) {
                return c.json({
                    statusCode: 500,
                    body: { reason: "Failed to process event" }
                }, 500);
            }
            return c.json({
                statusCode: 200,
                body: {
                    successful_events: [result],
                    failed_events: []
                }
            }, 200);
        }
        // Otherwise, handle as bulk operation
        else {
            const successfulEvents = [];
            const failedEvents = [];
            // Process events for each device in parallel
            await Promise.all(deviceIds.map(async (deviceId) => {
                try {
                    let result = null;
                    // Create event with appropriate handler based on event type
                    if (eventType === eventsSchema_ts_1.EventType.LOAD_UP) {
                        result = await (0, loadUp_ts_1.handleLoadUp)(deviceId, 'start_time' in eventData && eventData.start_time ? new Date(eventData.start_time) : undefined, 'duration' in eventData ? eventData.duration : undefined);
                    }
                    else if (eventType === eventsSchema_ts_1.EventType.GRID_EMERGENCY) {
                        result = await (0, gridEmergency_ts_1.handleGridEmergency)(deviceId, 'start_time' in eventData && eventData.start_time ? new Date(eventData.start_time) : undefined);
                    }
                    else if (eventType === eventsSchema_ts_1.EventType.CRITICAL_PEAK) {
                        result = await (0, criticalPeak_ts_1.handleCriticalPeak)(deviceId, 'start_time' in eventData && eventData.start_time ? new Date(eventData.start_time) : undefined);
                    }
                    else if (eventType === eventsSchema_ts_1.EventType.START_SHED) {
                        result = await (0, startShed_ts_1.handleStartShed)(deviceId, 'start_time' in eventData && eventData.start_time ? new Date(eventData.start_time) : undefined, 'duration' in eventData ? eventData.duration || 0 : 0);
                    }
                    else if (eventType === eventsSchema_ts_1.EventType.END_SHED) {
                        result = await (0, endShed_ts_1.handleEndShed)(deviceId, 'start_time' in eventData && eventData.start_time ? new Date(eventData.start_time) : undefined);
                    }
                    else if (eventType === eventsSchema_ts_1.EventType.INFO_REQUEST) {
                        result = await (0, infoRequest_ts_1.handleInfoRequest)(deviceId, 'timestamp' in eventData && eventData.timestamp ? new Date(eventData.timestamp) : undefined);
                    }
                    else if (eventType === eventsSchema_ts_1.EventType.ADVANCED_LOAD_UP) {
                        const startTime = 'start_time' in eventData && eventData.start_time
                            ? new Date(eventData.start_time)
                            : new Date();
                        const duration = 'duration' in eventData ? eventData.duration || 0 : 0;
                        const value = 'value' in eventData ? eventData.value || 0 : 0;
                        const units = 'units' in eventData ? eventData.units || 0 : 0;
                        const suggestedLoadUpEfficiency = 'suggested_load_up_efficiency' in eventData ? eventData.suggested_load_up_efficiency || 0 : 0;
                        const startRandomization = 'start_randomization' in eventData ? eventData.start_randomization || 0 : 0;
                        const endRandomization = 'end_randomization' in eventData ? eventData.end_randomization || 0 : 0;
                        result = await (0, advancedLoadUp_ts_1.handleAdvancedLoadUp)(deviceId, startTime, duration, value, units, suggestedLoadUpEfficiency, 'event_id' in eventData ? eventData.event_id : (0, uuid_1.v4)(), startRandomization, endRandomization);
                    }
                    else if (eventType === eventsSchema_ts_1.EventType.CUSTOMER_OVERRIDE) {
                        result = await (0, customerOverride_ts_1.handleCustomerOverride)(deviceId, 'override' in eventData ? eventData.override : false);
                    }
                    else if (eventType === eventsSchema_ts_1.EventType.SET_UTC_TIME) {
                        result = await (0, setUtcTime_ts_1.handleSetUtcTime)(eventData);
                    }
                    else if (eventType === eventsSchema_ts_1.EventType.GET_UTC_TIME) {
                        result = await (0, getUtcTime_ts_1.handleGetUtcTime)(eventData);
                    }
                    else if (eventType === eventsSchema_ts_1.EventType.SET_BITMAP) {
                        result = await (0, setBitmap_ts_1.handleSetBitmap)(eventData);
                    }
                    else if (eventType === eventsSchema_ts_1.EventType.REQUEST_CONNECTION_INFO) {
                        result = await (0, requestConnectionInfo_ts_1.handleRequestConnectionInfo)({
                            device_id: deviceId,
                            event_sent: false
                        });
                    }
                    if (result) {
                        successfulEvents.push(result);
                    }
                    else {
                        failedEvents.push({
                            device_id: deviceId,
                            error: "Failed to process event"
                        });
                    }
                }
                catch (error) {
                    console.error(`Error processing event for device ${deviceId}:`, error);
                    failedEvents.push({
                        device_id: deviceId,
                        error: error instanceof Error ? error.message : "Unknown error"
                    });
                }
            }));
            // Return the results
            return c.json({
                statusCode: 200,
                body: {
                    successful_events: successfulEvents,
                    failed_events: failedEvents.length > 0 ? failedEvents : []
                }
            }, 200);
        }
    }
    catch (error) {
        console.error("Error processing event:", error);
        return c.json({
            statusCode: 500,
            body: { reason: error instanceof Error ? error.message : "Unknown error" }
        }, 500);
    }
});
exports.default = app;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXZlbnRzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZXZlbnRzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsK0JBQTRCO0FBQzVCLDhEQUFvRDtBQUVwRCwwREFBb0Q7QUFDcEQsdURBQWtJO0FBQ2xJLCtDQUE2QztBQUM3QywwQ0FBcUU7QUFDckUseURBQXlEO0FBQ3pELCtEQUErRDtBQUMvRCwyREFBMkQ7QUFDM0QsdUVBQXVFO0FBQ3ZFLHFFQUFxRTtBQUNyRSxtRUFBbUU7QUFDbkUseUVBQXlFO0FBQ3pFLDZFQUE2RTtBQUM3RSxpRUFBaUU7QUFDakUsaUVBQWlFO0FBQ2pFLCtEQUErRDtBQUMvRCx1RkFBdUY7QUFDdkYsK0JBQW9DO0FBRXBDLE1BQU0sR0FBRyxHQUFHLElBQUksV0FBSSxFQUFFLENBQUE7QUFFdEIsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQ1AsSUFBQSw0QkFBYSxFQUFDO0lBQ1YsV0FBVyxFQUFFLGtCQUFrQjtJQUMvQixTQUFTLEVBQUU7UUFDUCxHQUFHLEVBQUU7WUFDRCxXQUFXLEVBQUUseUJBQXlCO1lBQ3RDLE9BQU8sRUFBRTtnQkFDTCxrQkFBa0IsRUFBRTtvQkFDaEIsTUFBTSxFQUFFLElBQUEsY0FBUSxFQUFDLDhCQUFZLENBQUM7aUJBQ2pDO2FBQ0o7U0FDSjtRQUNELEdBQUcsRUFBRTtZQUNELFdBQVcsRUFBRSx1QkFBdUI7U0FDdkM7S0FDSjtDQUNKLENBQUMsRUFDRixLQUFLLEVBQUUsQ0FBQyxFQUFFLEVBQUU7SUFDUixJQUFJLENBQUM7UUFDRCxNQUFNLFFBQVEsR0FBRyxJQUFJLDBCQUFRLENBQUMsRUFBRSxRQUFRLEVBQUUsV0FBVyxFQUFFLENBQUMsQ0FBQztRQUN6RCxNQUFNLE9BQU8sR0FBRyxNQUFNLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxTQUFTLEVBQUUsWUFBWSxFQUFFLENBQUMsQ0FBQztRQUVqRSxxREFBcUQ7UUFDckQsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDckMsTUFBTSxLQUFLLEdBQUcsSUFBQSwwQkFBVSxFQUFDLElBQUksQ0FBQyxDQUFDO1lBRS9CLDhEQUE4RDtZQUM5RCxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUNwQixLQUFLLENBQUMsVUFBVSxHQUFHO29CQUNmLFNBQVMsRUFBRSxLQUFLLENBQUMsU0FBUyxJQUFJLEVBQUU7aUJBQ25DLENBQUM7Z0JBRUYsNkNBQTZDO2dCQUM3QyxJQUFJLEtBQUssQ0FBQyxVQUFVLEtBQUssMkJBQVMsQ0FBQyxZQUFZLEVBQUUsQ0FBQztvQkFDOUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDLFNBQVMsSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUM3RSxDQUFDO3FCQUFNLElBQUksQ0FBQyxTQUFTLEVBQUUsZ0JBQWdCLEVBQUUsZUFBZSxFQUFFLFlBQVksRUFBRSxVQUFVLEVBQUUsbUJBQW1CLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUM7b0JBQ2xJLEtBQUssQ0FBQyxVQUFVLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQyxVQUFVLElBQUksSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztvQkFFM0UsNENBQTRDO29CQUM1QyxJQUFJLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQzt3QkFDdkQsS0FBSyxDQUFDLFVBQVUsQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDLFFBQVEsSUFBSSxDQUFDLENBQUM7b0JBQ3BELENBQUM7Z0JBQ0wsQ0FBQztZQUNMLENBQUM7WUFFRCx3REFBd0Q7WUFDeEQsSUFBSSxLQUFLLENBQUMsU0FBUyxLQUFLLFNBQVMsRUFBRSxDQUFDO2dCQUNoQyxLQUFLLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUM7WUFDdEMsQ0FBQztpQkFBTSxDQUFDO2dCQUNKLEtBQUssQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO1lBQzVCLENBQUM7WUFFRCxPQUFPLEtBQUssQ0FBQztRQUNqQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUM7UUFFVCxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsOEJBQVksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNiLE9BQU8sQ0FBQyxLQUFLLENBQUMsd0JBQXdCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDL0MsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxFQUFFLHdCQUF3QixFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDNUQsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFBO0FBRU4sR0FBRyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsRUFDdkIsSUFBQSw0QkFBYSxFQUFDO0lBQ1YsV0FBVyxFQUFFLG9DQUFvQztJQUNqRCxTQUFTLEVBQUU7UUFDUCxHQUFHLEVBQUU7WUFDRCxXQUFXLEVBQUUsOEJBQThCO1lBQzNDLE9BQU8sRUFBRTtnQkFDTCxrQkFBa0IsRUFBRTtvQkFDaEIsTUFBTSxFQUFFLElBQUEsY0FBUSxFQUFDLDhCQUFZLENBQUM7aUJBQ2pDO2FBQ0o7U0FDSjtRQUNELEdBQUcsRUFBRTtZQUNELFdBQVcsRUFBRSxpQ0FBaUM7U0FDakQ7UUFDRCxHQUFHLEVBQUU7WUFDRCxXQUFXLEVBQUUsdUJBQXVCO1NBQ3ZDO0tBQ0o7Q0FDSixDQUFDLEVBQ0YsS0FBSyxFQUFFLENBQUMsRUFBRSxFQUFFO0lBQ1IsSUFBSSxDQUFDO1FBQ0QsTUFBTSxRQUFRLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDekMsTUFBTSxRQUFRLEdBQUcsSUFBSSwwQkFBUSxDQUFDLEVBQUUsUUFBUSxFQUFFLFdBQVcsRUFBRSxDQUFDLENBQUM7UUFFekQsNEJBQTRCO1FBQzVCLE1BQU0sV0FBVyxHQUFHO1lBQ2hCLFNBQVMsRUFBRSxZQUFZO1lBQ3ZCLFNBQVMsRUFBRSxpQkFBaUI7WUFDNUIsc0JBQXNCLEVBQUUsdUJBQXVCO1lBQy9DLHlCQUF5QixFQUFFO2dCQUN2QixXQUFXLEVBQUUsRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFO2FBQy9CO1NBQ0osQ0FBQztRQUVGLE1BQU0sT0FBTyxHQUFHLE1BQU0sUUFBUSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUVsRCxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUMvQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLEVBQUUsaUNBQWlDLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNyRSxDQUFDO1FBRUQscURBQXFEO1FBQ3JELE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ3BDLE1BQU0sS0FBSyxHQUFHLElBQUEsMEJBQVUsRUFBQyxJQUFJLENBQUMsQ0FBQztZQUUvQiw4REFBOEQ7WUFDOUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDcEIsS0FBSyxDQUFDLFVBQVUsR0FBRztvQkFDZixTQUFTLEVBQUUsS0FBSyxDQUFDLFNBQVMsSUFBSSxRQUFRO2lCQUN6QyxDQUFDO2dCQUVGLDZDQUE2QztnQkFDN0MsSUFBSSxLQUFLLENBQUMsVUFBVSxLQUFLLDJCQUFTLENBQUMsWUFBWSxFQUFFLENBQUM7b0JBQzlDLEtBQUssQ0FBQyxVQUFVLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQyxTQUFTLElBQUksSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDN0UsQ0FBQztxQkFBTSxJQUFJLENBQUMsU0FBUyxFQUFFLGdCQUFnQixFQUFFLGVBQWUsRUFBRSxZQUFZLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDO29CQUNsSSxLQUFLLENBQUMsVUFBVSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUMsVUFBVSxJQUFJLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUM7b0JBRTNFLDRDQUE0QztvQkFDNUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUM7d0JBQ3ZELEtBQUssQ0FBQyxVQUFVLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxRQUFRLElBQUksQ0FBQyxDQUFDO29CQUNwRCxDQUFDO2dCQUNMLENBQUM7WUFDTCxDQUFDO1lBRUQseURBQXlEO1lBQ3pELDZEQUE2RDtZQUM3RCxJQUFJLEtBQUssQ0FBQyxTQUFTLEtBQUssU0FBUyxFQUFFLENBQUM7Z0JBQ2hDLEtBQUssQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQztZQUN0QyxDQUFDO2lCQUFNLENBQUM7Z0JBQ0osS0FBSyxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7WUFDNUIsQ0FBQztZQUVELE9BQU8sS0FBSyxDQUFDO1FBQ2pCLENBQUMsQ0FBQyxDQUFDO1FBRUgsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLDhCQUFZLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDYixPQUFPLENBQUMsS0FBSyxDQUFDLCtCQUErQixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ3RELE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssRUFBRSwrQkFBK0IsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ25FLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQTtBQUVOLEdBQUcsQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUNmLElBQUEsNEJBQWEsRUFBQztJQUNWLFdBQVcsRUFBRSxvQkFBb0I7SUFDakMsU0FBUyxFQUFFO1FBQ1AsR0FBRyxFQUFFO1lBQ0QsV0FBVyxFQUFFLHlCQUF5QjtZQUN0QyxPQUFPLEVBQUU7Z0JBQ0wsa0JBQWtCLEVBQUU7b0JBQ2hCLE1BQU0sRUFBRSxJQUFBLGNBQVEsRUFBQyw2QkFBVyxDQUFDO2lCQUNoQzthQUNKO1NBQ0o7UUFDRCxHQUFHLEVBQUU7WUFDRCxXQUFXLEVBQUUsaUJBQWlCO1NBQ2pDO1FBQ0QsR0FBRyxFQUFFO1lBQ0QsV0FBVyxFQUFFLHVCQUF1QjtTQUN2QztLQUNKO0NBQ0osQ0FBQyxFQUNGLEtBQUssRUFBRSxDQUFDLEVBQUUsRUFBRTtJQUNSLElBQUksQ0FBQztRQUNELE1BQU0sUUFBUSxHQUFHLElBQUksMEJBQVEsQ0FBQyxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBQ3pELE1BQU0sT0FBTyxHQUFHLE1BQU0sUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLFNBQVMsRUFBRSxZQUFZLEVBQUUsR0FBRyxFQUFFLEVBQUUsUUFBUSxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDdEgsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNoQixPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLEVBQUUsaUJBQWlCLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNyRCxDQUFDO1FBRUQsTUFBTSxLQUFLLEdBQUcsSUFBQSwwQkFBVSxFQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUV2Qyw4REFBOEQ7UUFDOUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNwQixLQUFLLENBQUMsVUFBVSxHQUFHO2dCQUNmLFNBQVMsRUFBRSxLQUFLLENBQUMsU0FBUyxJQUFJLEVBQUU7YUFDbkMsQ0FBQztZQUVGLDZDQUE2QztZQUM3QyxJQUFJLEtBQUssQ0FBQyxVQUFVLEtBQUssMkJBQVMsQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDOUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDLFNBQVMsSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzdFLENBQUM7aUJBQU0sSUFBSSxDQUFDLFNBQVMsRUFBRSxnQkFBZ0IsRUFBRSxlQUFlLEVBQUUsWUFBWSxFQUFFLFVBQVUsRUFBRSxtQkFBbUIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQztnQkFDbEksS0FBSyxDQUFDLFVBQVUsQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDLFVBQVUsSUFBSSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUUzRSw0Q0FBNEM7Z0JBQzVDLElBQUksQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDO29CQUN2RCxLQUFLLENBQUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUMsUUFBUSxJQUFJLENBQUMsQ0FBQztnQkFDcEQsQ0FBQztZQUNMLENBQUM7UUFDTCxDQUFDO1FBRUQsd0RBQXdEO1FBQ3hELElBQUksS0FBSyxDQUFDLFNBQVMsS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUNoQyxLQUFLLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUM7UUFDdEMsQ0FBQzthQUFNLENBQUM7WUFDSixLQUFLLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztRQUM1QixDQUFDO1FBRUQsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLDZCQUFXLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDYixPQUFPLENBQUMsS0FBSyxDQUFDLHVCQUF1QixFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQzlDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssRUFBRSx1QkFBdUIsRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQzNELENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQTtBQUVOLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUNSLElBQUEsNEJBQWEsRUFBQztJQUNWLFdBQVcsRUFBRSw2Q0FBNkM7SUFDMUQsU0FBUyxFQUFFO1FBQ1AsR0FBRyxFQUFFO1lBQ0QsV0FBVyxFQUFFLCtCQUErQjtZQUM1QyxPQUFPLEVBQUU7Z0JBQ0wsa0JBQWtCLEVBQUU7b0JBQ2hCLE1BQU0sRUFBRSxJQUFBLGNBQVEsRUFBQyxvQ0FBa0IsQ0FBQztpQkFDdkM7YUFDSjtTQUNKO1FBQ0QsR0FBRyxFQUFFO1lBQ0QsV0FBVyxFQUFFLGFBQWE7U0FDN0I7UUFDRCxHQUFHLEVBQUU7WUFDRCxXQUFXLEVBQUUsdUJBQXVCO1NBQ3ZDO0tBQ0o7Q0FDSixDQUFDLEVBQ0YsSUFBQSxlQUFVLEVBQUMsTUFBTSxFQUFFLG9DQUFrQixDQUFDLEVBQ3RDLEtBQUssRUFBRSxDQUFDLEVBQUUsRUFBRTtJQUNSLElBQUksQ0FBQztRQUNELE1BQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNoQyxNQUFNLFVBQVUsR0FBRyxvQ0FBa0IsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFbEQsSUFBSSxNQUFNLEdBQTJCLElBQUksQ0FBQztRQUMxQyxNQUFNLFNBQVMsR0FBRyxVQUFVLENBQUMsVUFBVSxDQUFDO1FBQ3hDLE1BQU0sU0FBUyxHQUFHLFVBQVUsQ0FBQyxVQUFVLENBQUM7UUFFeEMsdURBQXVEO1FBQ3ZELE1BQU0sU0FBUyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQztZQUNoRCxDQUFDLENBQUMsU0FBUyxDQUFDLFNBQVM7WUFDckIsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRTVCLGlEQUFpRDtRQUNqRCxJQUFJLFNBQVMsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDekIsTUFBTSxRQUFRLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRTlCLDREQUE0RDtZQUM1RCxJQUFJLFNBQVMsS0FBSywyQkFBUyxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUNsQyxNQUFNLEdBQUcsTUFBTSxJQUFBLHdCQUFZLEVBQ3ZCLFFBQVEsRUFDUixZQUFZLElBQUksU0FBUyxJQUFJLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUM5RixVQUFVLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQzNELENBQUM7WUFDTixDQUFDO2lCQUNJLElBQUksU0FBUyxLQUFLLDJCQUFTLENBQUMsY0FBYyxFQUFFLENBQUM7Z0JBQzlDLE1BQU0sR0FBRyxNQUFNLElBQUEsc0NBQW1CLEVBQzlCLFFBQVEsRUFDUixZQUFZLElBQUksU0FBUyxJQUFJLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUNqRyxDQUFDO1lBQ04sQ0FBQztpQkFDSSxJQUFJLFNBQVMsS0FBSywyQkFBUyxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUM3QyxNQUFNLEdBQUcsTUFBTSxJQUFBLG9DQUFrQixFQUM3QixRQUFRLEVBQ1IsWUFBWSxJQUFJLFNBQVMsSUFBSSxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FDakcsQ0FBQztZQUNOLENBQUM7aUJBQ0ksSUFBSSxTQUFTLEtBQUssMkJBQVMsQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDMUMsTUFBTSxHQUFHLE1BQU0sSUFBQSw4QkFBZSxFQUMxQixRQUFRLEVBQ1IsWUFBWSxJQUFJLFNBQVMsSUFBSSxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFDOUYsVUFBVSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FDeEQsQ0FBQztZQUNOLENBQUM7aUJBQ0ksSUFBSSxTQUFTLEtBQUssMkJBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztnQkFDeEMsTUFBTSxHQUFHLE1BQU0sSUFBQSwwQkFBYSxFQUN4QixRQUFRLEVBQ1IsWUFBWSxJQUFJLFNBQVMsSUFBSSxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FDakcsQ0FBQztZQUNOLENBQUM7aUJBQ0ksSUFBSSxTQUFTLEtBQUssMkJBQVMsQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDNUMsTUFBTSxHQUFHLE1BQU0sSUFBQSxrQ0FBaUIsRUFDNUIsUUFBUSxFQUNSLFdBQVcsSUFBSSxTQUFTLElBQUksU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQzlGLENBQUM7WUFDTixDQUFDO2lCQUNJLElBQUksU0FBUyxLQUFLLDJCQUFTLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDaEQsTUFBTSxTQUFTLEdBQUcsWUFBWSxJQUFJLFNBQVMsSUFBSSxTQUFTLENBQUMsVUFBVTtvQkFDL0QsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUM7b0JBQ2hDLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxDQUFDO2dCQUNqQixNQUFNLFFBQVEsR0FBRyxVQUFVLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN2RSxNQUFNLEtBQUssR0FBRyxPQUFPLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUM5RCxNQUFNLEtBQUssR0FBRyxPQUFPLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUM5RCxNQUFNLHlCQUF5QixHQUFHLDhCQUE4QixJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLDRCQUE0QixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNoSSxNQUFNLGtCQUFrQixHQUFHLHFCQUFxQixJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLG1CQUFtQixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN2RyxNQUFNLGdCQUFnQixHQUFHLG1CQUFtQixJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLGlCQUFpQixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNqRyxNQUFNLEdBQUcsTUFBTSxJQUFBLHdDQUFvQixFQUMvQixRQUFRLEVBQ1IsU0FBUyxFQUNULFFBQVEsRUFDUixLQUFLLEVBQ0wsS0FBSyxFQUNMLHlCQUF5QixFQUN6QixVQUFVLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFBLFNBQU0sR0FBRSxFQUN2RCxrQkFBa0IsRUFDbEIsZ0JBQWdCLENBQ25CLENBQUM7WUFDTixDQUFDO2lCQUNJLElBQUksU0FBUyxLQUFLLDJCQUFTLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztnQkFDakQsTUFBTSxHQUFHLE1BQU0sSUFBQSw0Q0FBc0IsRUFDakMsUUFBUSxFQUNSLFVBQVUsSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FDdkQsQ0FBQztZQUNOLENBQUM7aUJBQ0ksSUFBSSxTQUFTLEtBQUssMkJBQVMsQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDNUMsTUFBTSxHQUFHLE1BQU0sSUFBQSxnQ0FBZ0IsRUFBQyxTQUFTLENBQUMsQ0FBQztZQUMvQyxDQUFDO2lCQUNJLElBQUksU0FBUyxLQUFLLDJCQUFTLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBQzVDLE1BQU0sR0FBRyxNQUFNLElBQUEsZ0NBQWdCLEVBQUMsU0FBUyxDQUFDLENBQUM7WUFDL0MsQ0FBQztpQkFDSSxJQUFJLFNBQVMsS0FBSywyQkFBUyxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUMxQyxNQUFNLEdBQUcsTUFBTSxJQUFBLDhCQUFlLEVBQUMsU0FBUyxDQUFDLENBQUM7WUFDOUMsQ0FBQztpQkFDSSxJQUFJLFNBQVMsS0FBSywyQkFBUyxDQUFDLHVCQUF1QixFQUFFLENBQUM7Z0JBQ3ZELE1BQU0sR0FBRyxNQUFNLElBQUEsc0RBQTJCLEVBQUM7b0JBQ3ZDLFNBQVMsRUFBRSxRQUFRO29CQUNuQixVQUFVLEVBQUUsS0FBSztpQkFDcEIsQ0FBQyxDQUFDO1lBQ1AsQ0FBQztpQkFDSSxDQUFDO2dCQUNGLHlCQUF5QjtnQkFDekIsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDO29CQUNWLFVBQVUsRUFBRSxHQUFHO29CQUNmLElBQUksRUFBRSxFQUFFLE1BQU0sRUFBRSwyQkFBMkIsU0FBUyxFQUFFLEVBQUU7aUJBQzNELEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDWixDQUFDO1lBRUQsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUNWLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQztvQkFDVixVQUFVLEVBQUUsR0FBRztvQkFDZixJQUFJLEVBQUUsRUFBRSxNQUFNLEVBQUUseUJBQXlCLEVBQUU7aUJBQzlDLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDWixDQUFDO1lBRUQsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDO2dCQUNWLFVBQVUsRUFBRSxHQUFHO2dCQUNmLElBQUksRUFBRTtvQkFDRixpQkFBaUIsRUFBRSxDQUFDLE1BQU0sQ0FBQztvQkFDM0IsYUFBYSxFQUFFLEVBQUU7aUJBQ3BCO2FBQ0osRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNaLENBQUM7UUFDRCxzQ0FBc0M7YUFDakMsQ0FBQztZQUNGLE1BQU0sZ0JBQWdCLEdBQXNCLEVBQUUsQ0FBQztZQUMvQyxNQUFNLFlBQVksR0FBMkMsRUFBRSxDQUFDO1lBRWhFLDZDQUE2QztZQUM3QyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsUUFBZ0IsRUFBRSxFQUFFO2dCQUN2RCxJQUFJLENBQUM7b0JBQ0QsSUFBSSxNQUFNLEdBQTJCLElBQUksQ0FBQztvQkFFMUMsNERBQTREO29CQUM1RCxJQUFJLFNBQVMsS0FBSywyQkFBUyxDQUFDLE9BQU8sRUFBRSxDQUFDO3dCQUNsQyxNQUFNLEdBQUcsTUFBTSxJQUFBLHdCQUFZLEVBQ3ZCLFFBQVEsRUFDUixZQUFZLElBQUksU0FBUyxJQUFJLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUM5RixVQUFVLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQzNELENBQUM7b0JBQ04sQ0FBQzt5QkFDSSxJQUFJLFNBQVMsS0FBSywyQkFBUyxDQUFDLGNBQWMsRUFBRSxDQUFDO3dCQUM5QyxNQUFNLEdBQUcsTUFBTSxJQUFBLHNDQUFtQixFQUM5QixRQUFRLEVBQ1IsWUFBWSxJQUFJLFNBQVMsSUFBSSxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FDakcsQ0FBQztvQkFDTixDQUFDO3lCQUNJLElBQUksU0FBUyxLQUFLLDJCQUFTLENBQUMsYUFBYSxFQUFFLENBQUM7d0JBQzdDLE1BQU0sR0FBRyxNQUFNLElBQUEsb0NBQWtCLEVBQzdCLFFBQVEsRUFDUixZQUFZLElBQUksU0FBUyxJQUFJLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUNqRyxDQUFDO29CQUNOLENBQUM7eUJBQ0ksSUFBSSxTQUFTLEtBQUssMkJBQVMsQ0FBQyxVQUFVLEVBQUUsQ0FBQzt3QkFDMUMsTUFBTSxHQUFHLE1BQU0sSUFBQSw4QkFBZSxFQUMxQixRQUFRLEVBQ1IsWUFBWSxJQUFJLFNBQVMsSUFBSSxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFDOUYsVUFBVSxJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FDeEQsQ0FBQztvQkFDTixDQUFDO3lCQUNJLElBQUksU0FBUyxLQUFLLDJCQUFTLENBQUMsUUFBUSxFQUFFLENBQUM7d0JBQ3hDLE1BQU0sR0FBRyxNQUFNLElBQUEsMEJBQWEsRUFDeEIsUUFBUSxFQUNSLFlBQVksSUFBSSxTQUFTLElBQUksU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQ2pHLENBQUM7b0JBQ04sQ0FBQzt5QkFDSSxJQUFJLFNBQVMsS0FBSywyQkFBUyxDQUFDLFlBQVksRUFBRSxDQUFDO3dCQUM1QyxNQUFNLEdBQUcsTUFBTSxJQUFBLGtDQUFpQixFQUM1QixRQUFRLEVBQ1IsV0FBVyxJQUFJLFNBQVMsSUFBSSxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FDOUYsQ0FBQztvQkFDTixDQUFDO3lCQUNJLElBQUksU0FBUyxLQUFLLDJCQUFTLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQzt3QkFDaEQsTUFBTSxTQUFTLEdBQUcsWUFBWSxJQUFJLFNBQVMsSUFBSSxTQUFTLENBQUMsVUFBVTs0QkFDL0QsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUM7NEJBQ2hDLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxDQUFDO3dCQUNqQixNQUFNLFFBQVEsR0FBRyxVQUFVLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN2RSxNQUFNLEtBQUssR0FBRyxPQUFPLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM5RCxNQUFNLEtBQUssR0FBRyxPQUFPLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM5RCxNQUFNLHlCQUF5QixHQUFHLDhCQUE4QixJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLDRCQUE0QixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNoSSxNQUFNLGtCQUFrQixHQUFHLHFCQUFxQixJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLG1CQUFtQixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUN2RyxNQUFNLGdCQUFnQixHQUFHLG1CQUFtQixJQUFJLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLGlCQUFpQixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNqRyxNQUFNLEdBQUcsTUFBTSxJQUFBLHdDQUFvQixFQUMvQixRQUFRLEVBQ1IsU0FBUyxFQUNULFFBQVEsRUFDUixLQUFLLEVBQ0wsS0FBSyxFQUNMLHlCQUF5QixFQUN6QixVQUFVLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFBLFNBQU0sR0FBRSxFQUN2RCxrQkFBa0IsRUFDbEIsZ0JBQWdCLENBQ25CLENBQUM7b0JBQ04sQ0FBQzt5QkFDSSxJQUFJLFNBQVMsS0FBSywyQkFBUyxDQUFDLGlCQUFpQixFQUFFLENBQUM7d0JBQ2pELE1BQU0sR0FBRyxNQUFNLElBQUEsNENBQXNCLEVBQ2pDLFFBQVEsRUFDUixVQUFVLElBQUksU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQ3ZELENBQUM7b0JBQ04sQ0FBQzt5QkFDSSxJQUFJLFNBQVMsS0FBSywyQkFBUyxDQUFDLFlBQVksRUFBRSxDQUFDO3dCQUM1QyxNQUFNLEdBQUcsTUFBTSxJQUFBLGdDQUFnQixFQUFDLFNBQVMsQ0FBQyxDQUFDO29CQUMvQyxDQUFDO3lCQUNJLElBQUksU0FBUyxLQUFLLDJCQUFTLENBQUMsWUFBWSxFQUFFLENBQUM7d0JBQzVDLE1BQU0sR0FBRyxNQUFNLElBQUEsZ0NBQWdCLEVBQUMsU0FBUyxDQUFDLENBQUM7b0JBQy9DLENBQUM7eUJBQ0ksSUFBSSxTQUFTLEtBQUssMkJBQVMsQ0FBQyxVQUFVLEVBQUUsQ0FBQzt3QkFDMUMsTUFBTSxHQUFHLE1BQU0sSUFBQSw4QkFBZSxFQUFDLFNBQVMsQ0FBQyxDQUFDO29CQUM5QyxDQUFDO3lCQUNJLElBQUksU0FBUyxLQUFLLDJCQUFTLENBQUMsdUJBQXVCLEVBQUUsQ0FBQzt3QkFDdkQsTUFBTSxHQUFHLE1BQU0sSUFBQSxzREFBMkIsRUFBQzs0QkFDdkMsU0FBUyxFQUFFLFFBQVE7NEJBQ25CLFVBQVUsRUFBRSxLQUFLO3lCQUNwQixDQUFDLENBQUM7b0JBQ1AsQ0FBQztvQkFFRCxJQUFJLE1BQU0sRUFBRSxDQUFDO3dCQUNULGdCQUFnQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztvQkFDbEMsQ0FBQzt5QkFBTSxDQUFDO3dCQUNKLFlBQVksQ0FBQyxJQUFJLENBQUM7NEJBQ2QsU0FBUyxFQUFFLFFBQVE7NEJBQ25CLEtBQUssRUFBRSx5QkFBeUI7eUJBQ25DLENBQUMsQ0FBQztvQkFDUCxDQUFDO2dCQUNMLENBQUM7Z0JBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztvQkFDYixPQUFPLENBQUMsS0FBSyxDQUFDLHFDQUFxQyxRQUFRLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztvQkFDdkUsWUFBWSxDQUFDLElBQUksQ0FBQzt3QkFDZCxTQUFTLEVBQUUsUUFBUTt3QkFDbkIsS0FBSyxFQUFFLEtBQUssWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGVBQWU7cUJBQ2xFLENBQUMsQ0FBQztnQkFDUCxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUVKLHFCQUFxQjtZQUNyQixPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ1YsVUFBVSxFQUFFLEdBQUc7Z0JBQ2YsSUFBSSxFQUFFO29CQUNGLGlCQUFpQixFQUFFLGdCQUFnQjtvQkFDbkMsYUFBYSxFQUFFLFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEVBQUU7aUJBQzdEO2FBQ0osRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNaLENBQUM7SUFDTCxDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNiLE9BQU8sQ0FBQyxLQUFLLENBQUMseUJBQXlCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDaEQsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ1YsVUFBVSxFQUFFLEdBQUc7WUFDZixJQUFJLEVBQUUsRUFBRSxNQUFNLEVBQUUsS0FBSyxZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsZUFBZSxFQUFFO1NBQzdFLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDWixDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUE7QUFFTixrQkFBZSxHQUFHLENBQUEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBIb25vIH0gZnJvbSBcImhvbm9cIjtcbmltcG9ydCB7IER5bmFtb0RCIH0gZnJvbSBcIkBhd3Mtc2RrL2NsaWVudC1keW5hbW9kYlwiO1xuaW1wb3J0IHsgSW9UV2lyZWxlc3MgfSBmcm9tIFwiQGF3cy1zZGsvY2xpZW50LWlvdC13aXJlbGVzc1wiO1xuaW1wb3J0IHsgdW5tYXJzaGFsbCB9IGZyb20gXCJAYXdzLXNkay91dGlsLWR5bmFtb2RiXCI7XG5pbXBvcnQgeyBldmVudHNTY2hlbWEsIGV2ZW50U2NoZW1hLCBldmVudFJlcXVlc3RTY2hlbWEsIGJ1bGtSZXNwb25zZVNjaGVtYSwgRXZlbnRUeXBlLCBFdmVudFNjaGVtYVR5cGUgfSBmcm9tICcuL2V2ZW50c1NjaGVtYS50cyc7XG5pbXBvcnQgeyBkZXNjcmliZVJvdXRlIH0gZnJvbSAnaG9uby1vcGVuYXBpJztcbmltcG9ydCB7IHJlc29sdmVyLCB2YWxpZGF0b3IgYXMgelZhbGlkYXRvciB9IGZyb20gXCJob25vLW9wZW5hcGkvem9kXCI7XG5pbXBvcnQgeyBoYW5kbGVMb2FkVXAgfSBmcm9tIFwiLi9ldmVudEhhbmRsZXJzL2xvYWRVcC50c1wiO1xuaW1wb3J0IHsgaGFuZGxlU3RhcnRTaGVkIH0gZnJvbSBcIi4vZXZlbnRIYW5kbGVycy9zdGFydFNoZWQudHNcIjtcbmltcG9ydCB7IGhhbmRsZUVuZFNoZWQgfSBmcm9tIFwiLi9ldmVudEhhbmRsZXJzL2VuZFNoZWQudHNcIjtcbmltcG9ydCB7IGhhbmRsZUdyaWRFbWVyZ2VuY3kgfSBmcm9tIFwiLi9ldmVudEhhbmRsZXJzL2dyaWRFbWVyZ2VuY3kudHNcIjtcbmltcG9ydCB7IGhhbmRsZUNyaXRpY2FsUGVhayB9IGZyb20gXCIuL2V2ZW50SGFuZGxlcnMvY3JpdGljYWxQZWFrLnRzXCI7XG5pbXBvcnQgeyBoYW5kbGVJbmZvUmVxdWVzdCB9IGZyb20gXCIuL2V2ZW50SGFuZGxlcnMvaW5mb1JlcXVlc3QudHNcIjtcbmltcG9ydCB7IGhhbmRsZUFkdmFuY2VkTG9hZFVwIH0gZnJvbSBcIi4vZXZlbnRIYW5kbGVycy9hZHZhbmNlZExvYWRVcC50c1wiO1xuaW1wb3J0IHsgaGFuZGxlQ3VzdG9tZXJPdmVycmlkZSB9IGZyb20gXCIuL2V2ZW50SGFuZGxlcnMvY3VzdG9tZXJPdmVycmlkZS50c1wiO1xuaW1wb3J0IHsgaGFuZGxlU2V0VXRjVGltZSB9IGZyb20gXCIuL2V2ZW50SGFuZGxlcnMvc2V0VXRjVGltZS50c1wiO1xuaW1wb3J0IHsgaGFuZGxlR2V0VXRjVGltZSB9IGZyb20gXCIuL2V2ZW50SGFuZGxlcnMvZ2V0VXRjVGltZS50c1wiO1xuaW1wb3J0IHsgaGFuZGxlU2V0Qml0bWFwIH0gZnJvbSAnLi9ldmVudEhhbmRsZXJzL3NldEJpdG1hcC50cyc7XG5pbXBvcnQgeyBoYW5kbGVSZXF1ZXN0Q29ubmVjdGlvbkluZm8gfSBmcm9tICcuL2V2ZW50SGFuZGxlcnMvcmVxdWVzdENvbm5lY3Rpb25JbmZvLnRzJztcbmltcG9ydCB7IHY0IGFzIHV1aWR2NCB9IGZyb20gJ3V1aWQnO1xuXG5jb25zdCBhcHAgPSBuZXcgSG9ubygpXG5cbmFwcC5nZXQoXCIvXCIsXG4gICAgZGVzY3JpYmVSb3V0ZSh7XG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkZldGNoIGFsbCBldmVudHNcIixcbiAgICAgICAgcmVzcG9uc2VzOiB7XG4gICAgICAgICAgICAyMDA6IHtcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJSZXRyaWV2ZSBMaXN0IG9mIEV2ZW50c1wiLFxuICAgICAgICAgICAgICAgIGNvbnRlbnQ6IHtcbiAgICAgICAgICAgICAgICAgICAgJ2FwcGxpY2F0aW9uL2pzb24nOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzY2hlbWE6IHJlc29sdmVyKGV2ZW50c1NjaGVtYSksXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICA1MDA6IHtcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJJbnRlcm5hbCBTZXJ2ZXIgRXJyb3JcIixcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgfSksXG4gICAgYXN5bmMgKGMpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGR5bmFtb2RiID0gbmV3IER5bmFtb0RCKHsgXCJyZWdpb25cIjogXCJ1cy1lYXN0LTFcIiB9KTtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCBkeW5hbW9kYi5zY2FuKHsgVGFibGVOYW1lOiBcIkRvYmJ5RXZlbnRcIiB9KTtcblxuICAgICAgICAgICAgLy8gVHJhbnNmb3JtIHRoZSBkYXRhIHRvIGVuc3VyZSBpdCBtYXRjaGVzIHRoZSBzY2hlbWFcbiAgICAgICAgICAgIGNvbnN0IGV2ZW50cyA9IHJlc3VsdHMuSXRlbXM/Lm1hcChpdGVtID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBldmVudCA9IHVubWFyc2hhbGwoaXRlbSk7XG5cbiAgICAgICAgICAgICAgICAvLyBNYWtlIHN1cmUgZXZlbnRfZGF0YSBleGlzdHMgYW5kIGhhcyB0aGUgbmVjZXNzYXJ5IHN0cnVjdHVyZVxuICAgICAgICAgICAgICAgIGlmICghZXZlbnQuZXZlbnRfZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICBldmVudC5ldmVudF9kYXRhID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgZGV2aWNlX2lkOiBldmVudC5kZXZpY2VfaWQgfHwgJydcbiAgICAgICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgICAgICAvLyBBZGQgYXBwcm9wcmlhdGUgZmllbGRzIGJhc2VkIG9uIGV2ZW50IHR5cGVcbiAgICAgICAgICAgICAgICAgICAgaWYgKGV2ZW50LmV2ZW50X3R5cGUgPT09IEV2ZW50VHlwZS5JTkZPX1JFUVVFU1QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGV2ZW50LmV2ZW50X2RhdGEudGltZXN0YW1wID0gZXZlbnQudGltZXN0YW1wIHx8IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChbJ0xPQURfVVAnLCAnR1JJRF9FTUVSR0VOQ1knLCAnQ1JJVElDQUxfUEVBSycsICdTVEFSVF9TSEVEJywgJ0VORF9TSEVEJywgJ0NVU1RPTUVSX09WRVJSSURFJ10uaW5jbHVkZXMoZXZlbnQuZXZlbnRfdHlwZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGV2ZW50LmV2ZW50X2RhdGEuc3RhcnRfdGltZSA9IGV2ZW50LnN0YXJ0X3RpbWUgfHwgbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBBZGQgZHVyYXRpb24gZm9yIGV2ZW50IHR5cGVzIHRoYXQgbmVlZCBpdFxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKFsnTE9BRF9VUCcsICdTVEFSVF9TSEVEJ10uaW5jbHVkZXMoZXZlbnQuZXZlbnRfdHlwZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBldmVudC5ldmVudF9kYXRhLmR1cmF0aW9uID0gZXZlbnQuZHVyYXRpb24gfHwgMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIENvcHkgZXZlbnRfYWNrIGRpcmVjdGx5IHRvIHRoZSB0b3AgbGV2ZWwgb2YgdGhlIGV2ZW50XG4gICAgICAgICAgICAgICAgaWYgKGV2ZW50LmV2ZW50X2FjayAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgIGV2ZW50LmV2ZW50X2FjayA9IGV2ZW50LmV2ZW50X2FjaztcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBldmVudC5ldmVudF9hY2sgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICByZXR1cm4gZXZlbnQ7XG4gICAgICAgICAgICB9KSB8fCBbXTtcblxuICAgICAgICAgICAgcmV0dXJuIGMuanNvbihldmVudHNTY2hlbWEucGFyc2UoZXZlbnRzKSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZXZlbnRzOlwiLCBlcnJvcik7XG4gICAgICAgICAgICByZXR1cm4gYy5qc29uKHsgZXJyb3I6IFwiRmFpbGVkIHRvIGZldGNoIGV2ZW50c1wiIH0sIDUwMCk7XG4gICAgICAgIH1cbiAgICB9KVxuXG5hcHAuZ2V0KFwiL2RldmljZS86ZGV2aWNlSWRcIixcbiAgICBkZXNjcmliZVJvdXRlKHtcbiAgICAgICAgZGVzY3JpcHRpb246IFwiRmV0Y2ggZXZlbnRzIGZvciBhIHNwZWNpZmljIGRldmljZVwiLFxuICAgICAgICByZXNwb25zZXM6IHtcbiAgICAgICAgICAgIDIwMDoge1xuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlJldHJpZXZlIGV2ZW50cyBmb3IgYSBkZXZpY2VcIixcbiAgICAgICAgICAgICAgICBjb250ZW50OiB7XG4gICAgICAgICAgICAgICAgICAgICdhcHBsaWNhdGlvbi9qc29uJzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2NoZW1hOiByZXNvbHZlcihldmVudHNTY2hlbWEpLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgNDA0OiB7XG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiTm8gZXZlbnRzIGZvdW5kIGZvciB0aGlzIGRldmljZVwiLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIDUwMDoge1xuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIkludGVybmFsIFNlcnZlciBFcnJvclwiLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICB9KSxcbiAgICBhc3luYyAoYykgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgZGV2aWNlSWQgPSBjLnJlcS5wYXJhbShcImRldmljZUlkXCIpO1xuICAgICAgICAgICAgY29uc3QgZHluYW1vZGIgPSBuZXcgRHluYW1vREIoeyBcInJlZ2lvblwiOiBcInVzLWVhc3QtMVwiIH0pO1xuXG4gICAgICAgICAgICAvLyBRdWVyeSB0aGUgR1NJIChkZXZpY2VfaWQpXG4gICAgICAgICAgICBjb25zdCBxdWVyeVBhcmFtcyA9IHtcbiAgICAgICAgICAgICAgICBUYWJsZU5hbWU6IFwiRG9iYnlFdmVudFwiLFxuICAgICAgICAgICAgICAgIEluZGV4TmFtZTogXCJkZXZpY2VfaWQtaW5kZXhcIixcbiAgICAgICAgICAgICAgICBLZXlDb25kaXRpb25FeHByZXNzaW9uOiBcImRldmljZV9pZCA9IDpkZXZpY2VJZFwiLFxuICAgICAgICAgICAgICAgIEV4cHJlc3Npb25BdHRyaWJ1dGVWYWx1ZXM6IHtcbiAgICAgICAgICAgICAgICAgICAgXCI6ZGV2aWNlSWRcIjogeyBTOiBkZXZpY2VJZCB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgY29uc3QgcmVzdWx0cyA9IGF3YWl0IGR5bmFtb2RiLnF1ZXJ5KHF1ZXJ5UGFyYW1zKTtcblxuICAgICAgICAgICAgaWYgKCFyZXN1bHRzLkl0ZW1zIHx8IHJlc3VsdHMuSXRlbXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGMuanNvbih7IGVycm9yOiBcIk5vIGV2ZW50cyBmb3VuZCBmb3IgdGhpcyBkZXZpY2VcIiB9LCA0MDQpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBUcmFuc2Zvcm0gdGhlIGRhdGEgdG8gZW5zdXJlIGl0IG1hdGNoZXMgdGhlIHNjaGVtYVxuICAgICAgICAgICAgY29uc3QgZXZlbnRzID0gcmVzdWx0cy5JdGVtcy5tYXAoaXRlbSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgZXZlbnQgPSB1bm1hcnNoYWxsKGl0ZW0pO1xuXG4gICAgICAgICAgICAgICAgLy8gTWFrZSBzdXJlIGV2ZW50X2RhdGEgZXhpc3RzIGFuZCBoYXMgdGhlIG5lY2Vzc2FyeSBzdHJ1Y3R1cmVcbiAgICAgICAgICAgICAgICBpZiAoIWV2ZW50LmV2ZW50X2RhdGEpIHtcbiAgICAgICAgICAgICAgICAgICAgZXZlbnQuZXZlbnRfZGF0YSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRldmljZV9pZDogZXZlbnQuZGV2aWNlX2lkIHx8IGRldmljZUlkXG4gICAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgICAgLy8gQWRkIGFwcHJvcHJpYXRlIGZpZWxkcyBiYXNlZCBvbiBldmVudCB0eXBlXG4gICAgICAgICAgICAgICAgICAgIGlmIChldmVudC5ldmVudF90eXBlID09PSBFdmVudFR5cGUuSU5GT19SRVFVRVNUKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBldmVudC5ldmVudF9kYXRhLnRpbWVzdGFtcCA9IGV2ZW50LnRpbWVzdGFtcCB8fCBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoWydMT0FEX1VQJywgJ0dSSURfRU1FUkdFTkNZJywgJ0NSSVRJQ0FMX1BFQUsnLCAnU1RBUlRfU0hFRCcsICdFTkRfU0hFRCcsICdDVVNUT01FUl9PVkVSUklERSddLmluY2x1ZGVzKGV2ZW50LmV2ZW50X3R5cGUpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBldmVudC5ldmVudF9kYXRhLnN0YXJ0X3RpbWUgPSBldmVudC5zdGFydF90aW1lIHx8IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gQWRkIGR1cmF0aW9uIGZvciBldmVudCB0eXBlcyB0aGF0IG5lZWQgaXRcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChbJ0xPQURfVVAnLCAnU1RBUlRfU0hFRCddLmluY2x1ZGVzKGV2ZW50LmV2ZW50X3R5cGUpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZXZlbnQuZXZlbnRfZGF0YS5kdXJhdGlvbiA9IGV2ZW50LmR1cmF0aW9uIHx8IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAvLyBDb3B5IGV2ZW50X2FjayBkaXJlY3RseSB0byB0aGUgdG9wIGxldmVsIG9mIHRoZSBldmVudCBcbiAgICAgICAgICAgICAgICAvLyBUaGlzIGlzIGZvciB0aGUgZnJvbnRlbmQgdG8gaGF2ZSBlYXN5IGFjY2VzcyB0byB0aGlzIGZpZWxkXG4gICAgICAgICAgICAgICAgaWYgKGV2ZW50LmV2ZW50X2FjayAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgIGV2ZW50LmV2ZW50X2FjayA9IGV2ZW50LmV2ZW50X2FjaztcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBldmVudC5ldmVudF9hY2sgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICByZXR1cm4gZXZlbnQ7XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgcmV0dXJuIGMuanNvbihldmVudHNTY2hlbWEucGFyc2UoZXZlbnRzKSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZGV2aWNlIGV2ZW50czpcIiwgZXJyb3IpO1xuICAgICAgICAgICAgcmV0dXJuIGMuanNvbih7IGVycm9yOiBcIkZhaWxlZCB0byBmZXRjaCBkZXZpY2UgZXZlbnRzXCIgfSwgNTAwKTtcbiAgICAgICAgfVxuICAgIH0pXG5cbmFwcC5nZXQoXCIvOmV2ZW50SWRcIixcbiAgICBkZXNjcmliZVJvdXRlKHtcbiAgICAgICAgZGVzY3JpcHRpb246IFwiRmV0Y2ggc2luZ2xlIGV2ZW50XCIsXG4gICAgICAgIHJlc3BvbnNlczoge1xuICAgICAgICAgICAgMjAwOiB7XG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiUmV0cmlldmUgYSBzaW5nbGUgZXZlbnRcIixcbiAgICAgICAgICAgICAgICBjb250ZW50OiB7XG4gICAgICAgICAgICAgICAgICAgICdhcHBsaWNhdGlvbi9qc29uJzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2NoZW1hOiByZXNvbHZlcihldmVudFNjaGVtYSksXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICA0MDQ6IHtcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJFdmVudCBub3QgZm91bmRcIixcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICA1MDA6IHtcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJJbnRlcm5hbCBTZXJ2ZXIgRXJyb3JcIixcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgfSksXG4gICAgYXN5bmMgKGMpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IGR5bmFtb2RiID0gbmV3IER5bmFtb0RCKHsgXCJyZWdpb25cIjogXCJ1cy1lYXN0LTFcIiB9KTtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdHMgPSBhd2FpdCBkeW5hbW9kYi5nZXRJdGVtKHsgVGFibGVOYW1lOiBcIkRvYmJ5RXZlbnRcIiwgS2V5OiB7IGV2ZW50X2lkOiB7IFM6IGMucmVxLnBhcmFtKFwiZXZlbnRJZFwiKSB9IH0gfSk7XG4gICAgICAgICAgICBpZiAoIXJlc3VsdHMuSXRlbSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBjLmpzb24oeyBlcnJvcjogXCJFdmVudCBub3QgZm91bmRcIiB9LCA0MDQpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBjb25zdCBldmVudCA9IHVubWFyc2hhbGwocmVzdWx0cy5JdGVtKTtcblxuICAgICAgICAgICAgLy8gTWFrZSBzdXJlIGV2ZW50X2RhdGEgZXhpc3RzIGFuZCBoYXMgdGhlIG5lY2Vzc2FyeSBzdHJ1Y3R1cmVcbiAgICAgICAgICAgIGlmICghZXZlbnQuZXZlbnRfZGF0YSkge1xuICAgICAgICAgICAgICAgIGV2ZW50LmV2ZW50X2RhdGEgPSB7XG4gICAgICAgICAgICAgICAgICAgIGRldmljZV9pZDogZXZlbnQuZGV2aWNlX2lkIHx8ICcnXG4gICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgIC8vIEFkZCBhcHByb3ByaWF0ZSBmaWVsZHMgYmFzZWQgb24gZXZlbnQgdHlwZVxuICAgICAgICAgICAgICAgIGlmIChldmVudC5ldmVudF90eXBlID09PSBFdmVudFR5cGUuSU5GT19SRVFVRVNUKSB7XG4gICAgICAgICAgICAgICAgICAgIGV2ZW50LmV2ZW50X2RhdGEudGltZXN0YW1wID0gZXZlbnQudGltZXN0YW1wIHx8IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKFsnTE9BRF9VUCcsICdHUklEX0VNRVJHRU5DWScsICdDUklUSUNBTF9QRUFLJywgJ1NUQVJUX1NIRUQnLCAnRU5EX1NIRUQnLCAnQ1VTVE9NRVJfT1ZFUlJJREUnXS5pbmNsdWRlcyhldmVudC5ldmVudF90eXBlKSkge1xuICAgICAgICAgICAgICAgICAgICBldmVudC5ldmVudF9kYXRhLnN0YXJ0X3RpbWUgPSBldmVudC5zdGFydF90aW1lIHx8IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcblxuICAgICAgICAgICAgICAgICAgICAvLyBBZGQgZHVyYXRpb24gZm9yIGV2ZW50IHR5cGVzIHRoYXQgbmVlZCBpdFxuICAgICAgICAgICAgICAgICAgICBpZiAoWydMT0FEX1VQJywgJ1NUQVJUX1NIRUQnXS5pbmNsdWRlcyhldmVudC5ldmVudF90eXBlKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZXZlbnQuZXZlbnRfZGF0YS5kdXJhdGlvbiA9IGV2ZW50LmR1cmF0aW9uIHx8IDA7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIENvcHkgZXZlbnRfYWNrIGRpcmVjdGx5IHRvIHRoZSB0b3AgbGV2ZWwgb2YgdGhlIGV2ZW50XG4gICAgICAgICAgICBpZiAoZXZlbnQuZXZlbnRfYWNrICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICBldmVudC5ldmVudF9hY2sgPSBldmVudC5ldmVudF9hY2s7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGV2ZW50LmV2ZW50X2FjayA9IGZhbHNlO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gYy5qc29uKGV2ZW50U2NoZW1hLnBhcnNlKGV2ZW50KSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZXZlbnQ6XCIsIGVycm9yKTtcbiAgICAgICAgICAgIHJldHVybiBjLmpzb24oeyBlcnJvcjogXCJGYWlsZWQgdG8gZmV0Y2ggZXZlbnRcIiB9LCA1MDApO1xuICAgICAgICB9XG4gICAgfSlcblxuYXBwLnBvc3QoXCIvXCIsXG4gICAgZGVzY3JpYmVSb3V0ZSh7XG4gICAgICAgIGRlc2NyaXB0aW9uOiBcIkNyZWF0ZSBldmVudChzKSBmb3Igb25lIG9yIG11bHRpcGxlIGRldmljZXNcIixcbiAgICAgICAgcmVzcG9uc2VzOiB7XG4gICAgICAgICAgICAyMDA6IHtcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJFdmVudChzKSBjcmVhdGVkIHN1Y2Nlc3NmdWxseVwiLFxuICAgICAgICAgICAgICAgIGNvbnRlbnQ6IHtcbiAgICAgICAgICAgICAgICAgICAgJ2FwcGxpY2F0aW9uL2pzb24nOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzY2hlbWE6IHJlc29sdmVyKGJ1bGtSZXNwb25zZVNjaGVtYSksXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICA0MDA6IHtcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJCYWQgUmVxdWVzdFwiLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIDUwMDoge1xuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIkludGVybmFsIFNlcnZlciBFcnJvclwiLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICB9KSxcbiAgICB6VmFsaWRhdG9yKCdqc29uJywgZXZlbnRSZXF1ZXN0U2NoZW1hKSxcbiAgICBhc3luYyAoYykgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgYm9keSA9IGF3YWl0IGMucmVxLmpzb24oKTtcbiAgICAgICAgICAgIGNvbnN0IHBhcnNlZEJvZHkgPSBldmVudFJlcXVlc3RTY2hlbWEucGFyc2UoYm9keSk7XG5cbiAgICAgICAgICAgIGxldCByZXN1bHQ6IEV2ZW50U2NoZW1hVHlwZSB8IG51bGwgPSBudWxsO1xuICAgICAgICAgICAgY29uc3QgZXZlbnRUeXBlID0gcGFyc2VkQm9keS5ldmVudF90eXBlO1xuICAgICAgICAgICAgY29uc3QgZXZlbnREYXRhID0gcGFyc2VkQm9keS5ldmVudF9kYXRhO1xuXG4gICAgICAgICAgICAvLyBIYW5kbGUgYm90aCBzaW5nbGUgZGV2aWNlX2lkIGFuZCBhcnJheSBvZiBkZXZpY2VfaWRzXG4gICAgICAgICAgICBjb25zdCBkZXZpY2VJZHMgPSBBcnJheS5pc0FycmF5KGV2ZW50RGF0YS5kZXZpY2VfaWQpXG4gICAgICAgICAgICAgICAgPyBldmVudERhdGEuZGV2aWNlX2lkXG4gICAgICAgICAgICAgICAgOiBbZXZlbnREYXRhLmRldmljZV9pZF07XG5cbiAgICAgICAgICAgIC8vIElmIG9ubHkgb25lIGRldmljZSwgaGFuZGxlIGFzIHNpbmdsZSBvcGVyYXRpb25cbiAgICAgICAgICAgIGlmIChkZXZpY2VJZHMubGVuZ3RoID09PSAxKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZGV2aWNlSWQgPSBkZXZpY2VJZHNbMF07XG5cbiAgICAgICAgICAgICAgICAvLyBDcmVhdGUgZXZlbnQgd2l0aCBhcHByb3ByaWF0ZSBoYW5kbGVyIGJhc2VkIG9uIGV2ZW50IHR5cGVcbiAgICAgICAgICAgICAgICBpZiAoZXZlbnRUeXBlID09PSBFdmVudFR5cGUuTE9BRF9VUCkge1xuICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBoYW5kbGVMb2FkVXAoXG4gICAgICAgICAgICAgICAgICAgICAgICBkZXZpY2VJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICdzdGFydF90aW1lJyBpbiBldmVudERhdGEgJiYgZXZlbnREYXRhLnN0YXJ0X3RpbWUgPyBuZXcgRGF0ZShldmVudERhdGEuc3RhcnRfdGltZSkgOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAnZHVyYXRpb24nIGluIGV2ZW50RGF0YSA/IGV2ZW50RGF0YS5kdXJhdGlvbiA6IHVuZGVmaW5lZFxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChldmVudFR5cGUgPT09IEV2ZW50VHlwZS5HUklEX0VNRVJHRU5DWSkge1xuICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBoYW5kbGVHcmlkRW1lcmdlbmN5KFxuICAgICAgICAgICAgICAgICAgICAgICAgZGV2aWNlSWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAnc3RhcnRfdGltZScgaW4gZXZlbnREYXRhICYmIGV2ZW50RGF0YS5zdGFydF90aW1lID8gbmV3IERhdGUoZXZlbnREYXRhLnN0YXJ0X3RpbWUpIDogdW5kZWZpbmVkXG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGV2ZW50VHlwZSA9PT0gRXZlbnRUeXBlLkNSSVRJQ0FMX1BFQUspIHtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgaGFuZGxlQ3JpdGljYWxQZWFrKFxuICAgICAgICAgICAgICAgICAgICAgICAgZGV2aWNlSWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAnc3RhcnRfdGltZScgaW4gZXZlbnREYXRhICYmIGV2ZW50RGF0YS5zdGFydF90aW1lID8gbmV3IERhdGUoZXZlbnREYXRhLnN0YXJ0X3RpbWUpIDogdW5kZWZpbmVkXG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGV2ZW50VHlwZSA9PT0gRXZlbnRUeXBlLlNUQVJUX1NIRUQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgaGFuZGxlU3RhcnRTaGVkKFxuICAgICAgICAgICAgICAgICAgICAgICAgZGV2aWNlSWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAnc3RhcnRfdGltZScgaW4gZXZlbnREYXRhICYmIGV2ZW50RGF0YS5zdGFydF90aW1lID8gbmV3IERhdGUoZXZlbnREYXRhLnN0YXJ0X3RpbWUpIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICAgICAgJ2R1cmF0aW9uJyBpbiBldmVudERhdGEgPyBldmVudERhdGEuZHVyYXRpb24gfHwgMCA6IDBcbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoZXZlbnRUeXBlID09PSBFdmVudFR5cGUuRU5EX1NIRUQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgaGFuZGxlRW5kU2hlZChcbiAgICAgICAgICAgICAgICAgICAgICAgIGRldmljZUlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgJ3N0YXJ0X3RpbWUnIGluIGV2ZW50RGF0YSAmJiBldmVudERhdGEuc3RhcnRfdGltZSA/IG5ldyBEYXRlKGV2ZW50RGF0YS5zdGFydF90aW1lKSA6IHVuZGVmaW5lZFxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChldmVudFR5cGUgPT09IEV2ZW50VHlwZS5JTkZPX1JFUVVFU1QpIHtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgaGFuZGxlSW5mb1JlcXVlc3QoXG4gICAgICAgICAgICAgICAgICAgICAgICBkZXZpY2VJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICd0aW1lc3RhbXAnIGluIGV2ZW50RGF0YSAmJiBldmVudERhdGEudGltZXN0YW1wID8gbmV3IERhdGUoZXZlbnREYXRhLnRpbWVzdGFtcCkgOiB1bmRlZmluZWRcbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoZXZlbnRUeXBlID09PSBFdmVudFR5cGUuQURWQU5DRURfTE9BRF9VUCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBzdGFydFRpbWUgPSAnc3RhcnRfdGltZScgaW4gZXZlbnREYXRhICYmIGV2ZW50RGF0YS5zdGFydF90aW1lXG4gICAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKGV2ZW50RGF0YS5zdGFydF90aW1lKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBkdXJhdGlvbiA9ICdkdXJhdGlvbicgaW4gZXZlbnREYXRhID8gZXZlbnREYXRhLmR1cmF0aW9uIHx8IDAgOiAwO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9ICd2YWx1ZScgaW4gZXZlbnREYXRhID8gZXZlbnREYXRhLnZhbHVlIHx8IDAgOiAwO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB1bml0cyA9ICd1bml0cycgaW4gZXZlbnREYXRhID8gZXZlbnREYXRhLnVuaXRzIHx8IDAgOiAwO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBzdWdnZXN0ZWRMb2FkVXBFZmZpY2llbmN5ID0gJ3N1Z2dlc3RlZF9sb2FkX3VwX2VmZmljaWVuY3knIGluIGV2ZW50RGF0YSA/IGV2ZW50RGF0YS5zdWdnZXN0ZWRfbG9hZF91cF9lZmZpY2llbmN5IHx8IDAgOiAwO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBzdGFydFJhbmRvbWl6YXRpb24gPSAnc3RhcnRfcmFuZG9taXphdGlvbicgaW4gZXZlbnREYXRhID8gZXZlbnREYXRhLnN0YXJ0X3JhbmRvbWl6YXRpb24gfHwgMCA6IDA7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGVuZFJhbmRvbWl6YXRpb24gPSAnZW5kX3JhbmRvbWl6YXRpb24nIGluIGV2ZW50RGF0YSA/IGV2ZW50RGF0YS5lbmRfcmFuZG9taXphdGlvbiB8fCAwIDogMDtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgaGFuZGxlQWR2YW5jZWRMb2FkVXAoXG4gICAgICAgICAgICAgICAgICAgICAgICBkZXZpY2VJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXJ0VGltZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGR1cmF0aW9uLFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICB1bml0cyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1Z2dlc3RlZExvYWRVcEVmZmljaWVuY3ksXG4gICAgICAgICAgICAgICAgICAgICAgICAnZXZlbnRfaWQnIGluIGV2ZW50RGF0YSA/IGV2ZW50RGF0YS5ldmVudF9pZCA6IHV1aWR2NCgpLFxuICAgICAgICAgICAgICAgICAgICAgICAgc3RhcnRSYW5kb21pemF0aW9uLFxuICAgICAgICAgICAgICAgICAgICAgICAgZW5kUmFuZG9taXphdGlvblxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChldmVudFR5cGUgPT09IEV2ZW50VHlwZS5DVVNUT01FUl9PVkVSUklERSkge1xuICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBoYW5kbGVDdXN0b21lck92ZXJyaWRlKFxuICAgICAgICAgICAgICAgICAgICAgICAgZGV2aWNlSWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAnb3ZlcnJpZGUnIGluIGV2ZW50RGF0YSA/IGV2ZW50RGF0YS5vdmVycmlkZSA6IGZhbHNlXG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGV2ZW50VHlwZSA9PT0gRXZlbnRUeXBlLlNFVF9VVENfVElNRSkge1xuICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBoYW5kbGVTZXRVdGNUaW1lKGV2ZW50RGF0YSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGV2ZW50VHlwZSA9PT0gRXZlbnRUeXBlLkdFVF9VVENfVElNRSkge1xuICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBoYW5kbGVHZXRVdGNUaW1lKGV2ZW50RGF0YSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGV2ZW50VHlwZSA9PT0gRXZlbnRUeXBlLlNFVF9CSVRNQVApIHtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgaGFuZGxlU2V0Qml0bWFwKGV2ZW50RGF0YSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGV2ZW50VHlwZSA9PT0gRXZlbnRUeXBlLlJFUVVFU1RfQ09OTkVDVElPTl9JTkZPKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlc3VsdCA9IGF3YWl0IGhhbmRsZVJlcXVlc3RDb25uZWN0aW9uSW5mbyh7XG4gICAgICAgICAgICAgICAgICAgICAgICBkZXZpY2VfaWQ6IGRldmljZUlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgZXZlbnRfc2VudDogZmFsc2VcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAvLyBVbnN1cHBvcnRlZCBldmVudCB0eXBlXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBjLmpzb24oe1xuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzQ29kZTogNDAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgYm9keTogeyByZWFzb246IGBVbnN1cHBvcnRlZCBldmVudCB0eXBlOiAke2V2ZW50VHlwZX1gIH1cbiAgICAgICAgICAgICAgICAgICAgfSwgNDAwKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBpZiAoIXJlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYy5qc29uKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1c0NvZGU6IDUwMCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvZHk6IHsgcmVhc29uOiBcIkZhaWxlZCB0byBwcm9jZXNzIGV2ZW50XCIgfVxuICAgICAgICAgICAgICAgICAgICB9LCA1MDApO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHJldHVybiBjLmpzb24oe1xuICAgICAgICAgICAgICAgICAgICBzdGF0dXNDb2RlOiAyMDAsXG4gICAgICAgICAgICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1Y2Nlc3NmdWxfZXZlbnRzOiBbcmVzdWx0XSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGZhaWxlZF9ldmVudHM6IFtdXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9LCAyMDApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gT3RoZXJ3aXNlLCBoYW5kbGUgYXMgYnVsayBvcGVyYXRpb25cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGNvbnN0IHN1Y2Nlc3NmdWxFdmVudHM6IEV2ZW50U2NoZW1hVHlwZVtdID0gW107XG4gICAgICAgICAgICAgICAgY29uc3QgZmFpbGVkRXZlbnRzOiB7IGRldmljZV9pZDogc3RyaW5nLCBlcnJvcjogc3RyaW5nIH1bXSA9IFtdO1xuXG4gICAgICAgICAgICAgICAgLy8gUHJvY2VzcyBldmVudHMgZm9yIGVhY2ggZGV2aWNlIGluIHBhcmFsbGVsXG4gICAgICAgICAgICAgICAgYXdhaXQgUHJvbWlzZS5hbGwoZGV2aWNlSWRzLm1hcChhc3luYyAoZGV2aWNlSWQ6IHN0cmluZykgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbGV0IHJlc3VsdDogRXZlbnRTY2hlbWFUeXBlIHwgbnVsbCA9IG51bGw7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIENyZWF0ZSBldmVudCB3aXRoIGFwcHJvcHJpYXRlIGhhbmRsZXIgYmFzZWQgb24gZXZlbnQgdHlwZVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGV2ZW50VHlwZSA9PT0gRXZlbnRUeXBlLkxPQURfVVApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBoYW5kbGVMb2FkVXAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRldmljZUlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnc3RhcnRfdGltZScgaW4gZXZlbnREYXRhICYmIGV2ZW50RGF0YS5zdGFydF90aW1lID8gbmV3IERhdGUoZXZlbnREYXRhLnN0YXJ0X3RpbWUpIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnZHVyYXRpb24nIGluIGV2ZW50RGF0YSA/IGV2ZW50RGF0YS5kdXJhdGlvbiA6IHVuZGVmaW5lZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChldmVudFR5cGUgPT09IEV2ZW50VHlwZS5HUklEX0VNRVJHRU5DWSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdCA9IGF3YWl0IGhhbmRsZUdyaWRFbWVyZ2VuY3koXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRldmljZUlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnc3RhcnRfdGltZScgaW4gZXZlbnREYXRhICYmIGV2ZW50RGF0YS5zdGFydF90aW1lID8gbmV3IERhdGUoZXZlbnREYXRhLnN0YXJ0X3RpbWUpIDogdW5kZWZpbmVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGV2ZW50VHlwZSA9PT0gRXZlbnRUeXBlLkNSSVRJQ0FMX1BFQUspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBoYW5kbGVDcml0aWNhbFBlYWsoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRldmljZUlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnc3RhcnRfdGltZScgaW4gZXZlbnREYXRhICYmIGV2ZW50RGF0YS5zdGFydF90aW1lID8gbmV3IERhdGUoZXZlbnREYXRhLnN0YXJ0X3RpbWUpIDogdW5kZWZpbmVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGV2ZW50VHlwZSA9PT0gRXZlbnRUeXBlLlNUQVJUX1NIRUQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBoYW5kbGVTdGFydFNoZWQoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRldmljZUlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnc3RhcnRfdGltZScgaW4gZXZlbnREYXRhICYmIGV2ZW50RGF0YS5zdGFydF90aW1lID8gbmV3IERhdGUoZXZlbnREYXRhLnN0YXJ0X3RpbWUpIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnZHVyYXRpb24nIGluIGV2ZW50RGF0YSA/IGV2ZW50RGF0YS5kdXJhdGlvbiB8fCAwIDogMFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChldmVudFR5cGUgPT09IEV2ZW50VHlwZS5FTkRfU0hFRCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdCA9IGF3YWl0IGhhbmRsZUVuZFNoZWQoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRldmljZUlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnc3RhcnRfdGltZScgaW4gZXZlbnREYXRhICYmIGV2ZW50RGF0YS5zdGFydF90aW1lID8gbmV3IERhdGUoZXZlbnREYXRhLnN0YXJ0X3RpbWUpIDogdW5kZWZpbmVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGV2ZW50VHlwZSA9PT0gRXZlbnRUeXBlLklORk9fUkVRVUVTVCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdCA9IGF3YWl0IGhhbmRsZUluZm9SZXF1ZXN0KFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXZpY2VJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ3RpbWVzdGFtcCcgaW4gZXZlbnREYXRhICYmIGV2ZW50RGF0YS50aW1lc3RhbXAgPyBuZXcgRGF0ZShldmVudERhdGEudGltZXN0YW1wKSA6IHVuZGVmaW5lZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChldmVudFR5cGUgPT09IEV2ZW50VHlwZS5BRFZBTkNFRF9MT0FEX1VQKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3RhcnRUaW1lID0gJ3N0YXJ0X3RpbWUnIGluIGV2ZW50RGF0YSAmJiBldmVudERhdGEuc3RhcnRfdGltZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKGV2ZW50RGF0YS5zdGFydF90aW1lKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZHVyYXRpb24gPSAnZHVyYXRpb24nIGluIGV2ZW50RGF0YSA/IGV2ZW50RGF0YS5kdXJhdGlvbiB8fCAwIDogMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9ICd2YWx1ZScgaW4gZXZlbnREYXRhID8gZXZlbnREYXRhLnZhbHVlIHx8IDAgOiAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHVuaXRzID0gJ3VuaXRzJyBpbiBldmVudERhdGEgPyBldmVudERhdGEudW5pdHMgfHwgMCA6IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3VnZ2VzdGVkTG9hZFVwRWZmaWNpZW5jeSA9ICdzdWdnZXN0ZWRfbG9hZF91cF9lZmZpY2llbmN5JyBpbiBldmVudERhdGEgPyBldmVudERhdGEuc3VnZ2VzdGVkX2xvYWRfdXBfZWZmaWNpZW5jeSB8fCAwIDogMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzdGFydFJhbmRvbWl6YXRpb24gPSAnc3RhcnRfcmFuZG9taXphdGlvbicgaW4gZXZlbnREYXRhID8gZXZlbnREYXRhLnN0YXJ0X3JhbmRvbWl6YXRpb24gfHwgMCA6IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZW5kUmFuZG9taXphdGlvbiA9ICdlbmRfcmFuZG9taXphdGlvbicgaW4gZXZlbnREYXRhID8gZXZlbnREYXRhLmVuZF9yYW5kb21pemF0aW9uIHx8IDAgOiAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdCA9IGF3YWl0IGhhbmRsZUFkdmFuY2VkTG9hZFVwKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXZpY2VJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhcnRUaW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkdXJhdGlvbixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVuaXRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdWdnZXN0ZWRMb2FkVXBFZmZpY2llbmN5LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnZXZlbnRfaWQnIGluIGV2ZW50RGF0YSA/IGV2ZW50RGF0YS5ldmVudF9pZCA6IHV1aWR2NCgpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGFydFJhbmRvbWl6YXRpb24sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVuZFJhbmRvbWl6YXRpb25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoZXZlbnRUeXBlID09PSBFdmVudFR5cGUuQ1VTVE9NRVJfT1ZFUlJJREUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBoYW5kbGVDdXN0b21lck92ZXJyaWRlKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXZpY2VJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ292ZXJyaWRlJyBpbiBldmVudERhdGEgPyBldmVudERhdGEub3ZlcnJpZGUgOiBmYWxzZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChldmVudFR5cGUgPT09IEV2ZW50VHlwZS5TRVRfVVRDX1RJTUUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBoYW5kbGVTZXRVdGNUaW1lKGV2ZW50RGF0YSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChldmVudFR5cGUgPT09IEV2ZW50VHlwZS5HRVRfVVRDX1RJTUUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQgPSBhd2FpdCBoYW5kbGVHZXRVdGNUaW1lKGV2ZW50RGF0YSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChldmVudFR5cGUgPT09IEV2ZW50VHlwZS5TRVRfQklUTUFQKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0ID0gYXdhaXQgaGFuZGxlU2V0Qml0bWFwKGV2ZW50RGF0YSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChldmVudFR5cGUgPT09IEV2ZW50VHlwZS5SRVFVRVNUX0NPTk5FQ1RJT05fSU5GTykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdCA9IGF3YWl0IGhhbmRsZVJlcXVlc3RDb25uZWN0aW9uSW5mbyh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRldmljZV9pZDogZGV2aWNlSWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV2ZW50X3NlbnQ6IGZhbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdWNjZXNzZnVsRXZlbnRzLnB1c2gocmVzdWx0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmFpbGVkRXZlbnRzLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXZpY2VfaWQ6IGRldmljZUlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlcnJvcjogXCJGYWlsZWQgdG8gcHJvY2VzcyBldmVudFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBwcm9jZXNzaW5nIGV2ZW50IGZvciBkZXZpY2UgJHtkZXZpY2VJZH06YCwgZXJyb3IpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZmFpbGVkRXZlbnRzLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRldmljZV9pZDogZGV2aWNlSWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3I6IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogXCJVbmtub3duIGVycm9yXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgICAgICAgICAgLy8gUmV0dXJuIHRoZSByZXN1bHRzXG4gICAgICAgICAgICAgICAgcmV0dXJuIGMuanNvbih7XG4gICAgICAgICAgICAgICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgICAgICAgICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgICAgICAgICAgICAgc3VjY2Vzc2Z1bF9ldmVudHM6IHN1Y2Nlc3NmdWxFdmVudHMsXG4gICAgICAgICAgICAgICAgICAgICAgICBmYWlsZWRfZXZlbnRzOiBmYWlsZWRFdmVudHMubGVuZ3RoID4gMCA/IGZhaWxlZEV2ZW50cyA6IFtdXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9LCAyMDApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHByb2Nlc3NpbmcgZXZlbnQ6XCIsIGVycm9yKTtcbiAgICAgICAgICAgIHJldHVybiBjLmpzb24oe1xuICAgICAgICAgICAgICAgIHN0YXR1c0NvZGU6IDUwMCxcbiAgICAgICAgICAgICAgICBib2R5OiB7IHJlYXNvbjogZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIiB9XG4gICAgICAgICAgICB9LCA1MDApO1xuICAgICAgICB9XG4gICAgfSlcblxuZXhwb3J0IGRlZmF1bHQgYXBwIl19