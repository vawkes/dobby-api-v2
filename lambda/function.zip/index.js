"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const aws_lambda_1 = require("hono/aws-lambda");
const devices_1 = __importDefault(require("./devices/devices"));
const events_1 = __importDefault(require("./events/events"));
const authRoutes_1 = __importDefault(require("./utils/authRoutes"));
const hono_1 = require("hono");
const hono_openapi_1 = require("hono-openapi");
const hono_api_reference_1 = require("@scalar/hono-api-reference");
const auth_1 = require("./utils/auth");
const cors_1 = require("hono/cors");
// Create the main app
const app = new hono_1.Hono();
// Add CORS middleware to handle cross-origin requests
app.use('*', (0, cors_1.cors)({
    origin: ['http://localhost:3000', 'https://localhost:3000', 'https://d1dz25mfg0xsp8.cloudfront.net', '*'],
    allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
    allowHeaders: ['Content-Type', 'Authorization', 'X-API-Key', 'X-Origin-Verify', 'X-Requested-With'],
    credentials: true,
    maxAge: 86400, // 24 hours
    exposeHeaders: ['Content-Length', 'Content-Type']
}));
// Create a separate router for public routes
const publicRoutes = new hono_1.Hono();
// Add auth routes to public routes (do this first so the routes are included in OpenAPI spec)
publicRoutes.route('/auth', authRoutes_1.default);
// Create a full app for OpenAPI documentation that includes all routes
const fullApp = new hono_1.Hono();
fullApp.route('/devices', devices_1.default);
fullApp.route('/events', events_1.default);
fullApp.route('/public/auth', authRoutes_1.default);
// Add OpenAPI documentation to public routes
publicRoutes.get('/openapi', (0, hono_openapi_1.openAPISpecs)(fullApp, {
    documentation: {
        info: {
            title: 'Vawkes GridCube API',
            version: '1.0.0',
            description: 'API for interacting with Vawkes GridCube devices.'
        },
        servers: [],
        tags: [
            { name: 'Devices', description: 'Device management endpoints' },
            { name: 'Events', description: 'Event data endpoints' },
            { name: 'Authentication', description: 'User authentication endpoints' }
        ],
        components: {
            securitySchemes: {
                bearerAuth: {
                    type: 'http',
                    scheme: 'bearer',
                    bearerFormat: 'JWT',
                    description: 'Enter JWT token for authentication'
                }
            }
        },
        security: [
            { bearerAuth: [] }
        ]
    },
}));
// Add API documentation UI to public routes
publicRoutes.get('/docs', (0, hono_api_reference_1.apiReference)({
    theme: 'saturn',
    spec: { url: '/prod/public/openapi' },
}));
// Mount the public routes at /public
app.route('/public', publicRoutes);
// Add a middleware that logs all incoming requests for debugging
app.use('*', async (c, next) => {
    console.log(`Request received: ${c.req.method} ${c.req.path}`);
    console.log('Headers:', JSON.stringify(c.req.header()));
    await next();
    console.log(`Response status: ${c.res.status}`);
});
// Add authentication middleware to protected routes
// Protected routes must be defined AFTER mounting public routes
const protectedRoutes = new hono_1.Hono();
protectedRoutes.use('/*', auth_1.auth);
protectedRoutes.route('/devices', devices_1.default);
protectedRoutes.route('/events', events_1.default);
// Mount the protected routes at the root level
app.route('/', protectedRoutes);
// Export the handler
exports.handler = (0, aws_lambda_1.handle)(app);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQSxnREFBd0M7QUFDeEMsZ0VBQXVDO0FBQ3ZDLDZEQUFvQztBQUNwQyxvRUFBMkM7QUFDM0MsK0JBQTJCO0FBQzNCLCtDQUEyQztBQUMzQyxtRUFBeUQ7QUFDekQsdUNBQW1DO0FBQ25DLG9DQUFnQztBQUVoQyxzQkFBc0I7QUFDdEIsTUFBTSxHQUFHLEdBQUcsSUFBSSxXQUFJLEVBQUUsQ0FBQTtBQUV0QixzREFBc0Q7QUFDdEQsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBQSxXQUFJLEVBQUM7SUFDZCxNQUFNLEVBQUUsQ0FBQyx1QkFBdUIsRUFBRSx3QkFBd0IsRUFBRSx1Q0FBdUMsRUFBRSxHQUFHLENBQUM7SUFDekcsWUFBWSxFQUFFLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUM7SUFDbEUsWUFBWSxFQUFFLENBQUMsY0FBYyxFQUFFLGVBQWUsRUFBRSxXQUFXLEVBQUUsaUJBQWlCLEVBQUUsa0JBQWtCLENBQUM7SUFDbkcsV0FBVyxFQUFFLElBQUk7SUFDakIsTUFBTSxFQUFFLEtBQUssRUFBRSxXQUFXO0lBQzFCLGFBQWEsRUFBRSxDQUFDLGdCQUFnQixFQUFFLGNBQWMsQ0FBQztDQUNwRCxDQUFDLENBQUMsQ0FBQTtBQUVILDZDQUE2QztBQUM3QyxNQUFNLFlBQVksR0FBRyxJQUFJLFdBQUksRUFBRSxDQUFBO0FBRS9CLDhGQUE4RjtBQUM5RixZQUFZLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxvQkFBVSxDQUFDLENBQUE7QUFFdkMsdUVBQXVFO0FBQ3ZFLE1BQU0sT0FBTyxHQUFHLElBQUksV0FBSSxFQUFFLENBQUE7QUFDMUIsT0FBTyxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsaUJBQU8sQ0FBQyxDQUFBO0FBQ2xDLE9BQU8sQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLGdCQUFNLENBQUMsQ0FBQTtBQUNoQyxPQUFPLENBQUMsS0FBSyxDQUFDLGNBQWMsRUFBRSxvQkFBVSxDQUFDLENBQUE7QUFFekMsNkNBQTZDO0FBQzdDLFlBQVksQ0FBQyxHQUFHLENBQ1osVUFBVSxFQUNWLElBQUEsMkJBQVksRUFBQyxPQUFPLEVBQUU7SUFDbEIsYUFBYSxFQUFFO1FBQ1gsSUFBSSxFQUFFO1lBQ0YsS0FBSyxFQUFFLHFCQUFxQjtZQUM1QixPQUFPLEVBQUUsT0FBTztZQUNoQixXQUFXLEVBQUUsbURBQW1EO1NBQ25FO1FBQ0QsT0FBTyxFQUFFLEVBQUU7UUFDWCxJQUFJLEVBQUU7WUFDRixFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLDZCQUE2QixFQUFFO1lBQy9ELEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsc0JBQXNCLEVBQUU7WUFDdkQsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsV0FBVyxFQUFFLCtCQUErQixFQUFFO1NBQzNFO1FBQ0QsVUFBVSxFQUFFO1lBQ1IsZUFBZSxFQUFFO2dCQUNiLFVBQVUsRUFBRTtvQkFDUixJQUFJLEVBQUUsTUFBTTtvQkFDWixNQUFNLEVBQUUsUUFBUTtvQkFDaEIsWUFBWSxFQUFFLEtBQUs7b0JBQ25CLFdBQVcsRUFBRSxvQ0FBb0M7aUJBQ3BEO2FBQ0o7U0FDSjtRQUNELFFBQVEsRUFBRTtZQUNOLEVBQUUsVUFBVSxFQUFFLEVBQUUsRUFBRTtTQUNyQjtLQUNKO0NBQ0osQ0FBQyxDQUNMLENBQUE7QUFFRCw0Q0FBNEM7QUFDNUMsWUFBWSxDQUFDLEdBQUcsQ0FDWixPQUFPLEVBQ1AsSUFBQSxpQ0FBWSxFQUFDO0lBQ1QsS0FBSyxFQUFFLFFBQVE7SUFDZixJQUFJLEVBQUUsRUFBRSxHQUFHLEVBQUUsc0JBQXNCLEVBQUU7Q0FDeEMsQ0FBQyxDQUNMLENBQUE7QUFFRCxxQ0FBcUM7QUFDckMsR0FBRyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUE7QUFFbEMsaUVBQWlFO0FBQ2pFLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLEVBQUU7SUFDM0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO0lBQy9ELE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDeEQsTUFBTSxJQUFJLEVBQUUsQ0FBQztJQUNiLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztBQUNwRCxDQUFDLENBQUMsQ0FBQTtBQUVGLG9EQUFvRDtBQUNwRCxnRUFBZ0U7QUFDaEUsTUFBTSxlQUFlLEdBQUcsSUFBSSxXQUFJLEVBQUUsQ0FBQztBQUNuQyxlQUFlLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxXQUFJLENBQUMsQ0FBQztBQUNoQyxlQUFlLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRSxpQkFBTyxDQUFDLENBQUM7QUFDM0MsZUFBZSxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsZ0JBQU0sQ0FBQyxDQUFDO0FBRXpDLCtDQUErQztBQUMvQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxlQUFlLENBQUMsQ0FBQztBQUVoQyxxQkFBcUI7QUFDUixRQUFBLE9BQU8sR0FBRyxJQUFBLG1CQUFNLEVBQUMsR0FBRyxDQUFDLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBoYW5kbGUgfSBmcm9tICdob25vL2F3cy1sYW1iZGEnXG5pbXBvcnQgZGV2aWNlcyBmcm9tICcuL2RldmljZXMvZGV2aWNlcydcbmltcG9ydCBldmVudHMgZnJvbSAnLi9ldmVudHMvZXZlbnRzJ1xuaW1wb3J0IGF1dGhSb3V0ZXMgZnJvbSAnLi91dGlscy9hdXRoUm91dGVzJ1xuaW1wb3J0IHsgSG9ubyB9IGZyb20gJ2hvbm8nXG5pbXBvcnQgeyBvcGVuQVBJU3BlY3MgfSBmcm9tICdob25vLW9wZW5hcGknXG5pbXBvcnQgeyBhcGlSZWZlcmVuY2UgfSBmcm9tICdAc2NhbGFyL2hvbm8tYXBpLXJlZmVyZW5jZSdcbmltcG9ydCB7IGF1dGggfSBmcm9tICcuL3V0aWxzL2F1dGgnXG5pbXBvcnQgeyBjb3JzIH0gZnJvbSAnaG9uby9jb3JzJ1xuXG4vLyBDcmVhdGUgdGhlIG1haW4gYXBwXG5jb25zdCBhcHAgPSBuZXcgSG9ubygpXG5cbi8vIEFkZCBDT1JTIG1pZGRsZXdhcmUgdG8gaGFuZGxlIGNyb3NzLW9yaWdpbiByZXF1ZXN0c1xuYXBwLnVzZSgnKicsIGNvcnMoe1xuICAgIG9yaWdpbjogWydodHRwOi8vbG9jYWxob3N0OjMwMDAnLCAnaHR0cHM6Ly9sb2NhbGhvc3Q6MzAwMCcsICdodHRwczovL2QxZHoyNW1mZzB4c3A4LmNsb3VkZnJvbnQubmV0JywgJyonXSxcbiAgICBhbGxvd01ldGhvZHM6IFsnR0VUJywgJ1BPU1QnLCAnUFVUJywgJ0RFTEVURScsICdPUFRJT05TJywgJ1BBVENIJ10sXG4gICAgYWxsb3dIZWFkZXJzOiBbJ0NvbnRlbnQtVHlwZScsICdBdXRob3JpemF0aW9uJywgJ1gtQVBJLUtleScsICdYLU9yaWdpbi1WZXJpZnknLCAnWC1SZXF1ZXN0ZWQtV2l0aCddLFxuICAgIGNyZWRlbnRpYWxzOiB0cnVlLFxuICAgIG1heEFnZTogODY0MDAsIC8vIDI0IGhvdXJzXG4gICAgZXhwb3NlSGVhZGVyczogWydDb250ZW50LUxlbmd0aCcsICdDb250ZW50LVR5cGUnXVxufSkpXG5cbi8vIENyZWF0ZSBhIHNlcGFyYXRlIHJvdXRlciBmb3IgcHVibGljIHJvdXRlc1xuY29uc3QgcHVibGljUm91dGVzID0gbmV3IEhvbm8oKVxuXG4vLyBBZGQgYXV0aCByb3V0ZXMgdG8gcHVibGljIHJvdXRlcyAoZG8gdGhpcyBmaXJzdCBzbyB0aGUgcm91dGVzIGFyZSBpbmNsdWRlZCBpbiBPcGVuQVBJIHNwZWMpXG5wdWJsaWNSb3V0ZXMucm91dGUoJy9hdXRoJywgYXV0aFJvdXRlcylcblxuLy8gQ3JlYXRlIGEgZnVsbCBhcHAgZm9yIE9wZW5BUEkgZG9jdW1lbnRhdGlvbiB0aGF0IGluY2x1ZGVzIGFsbCByb3V0ZXNcbmNvbnN0IGZ1bGxBcHAgPSBuZXcgSG9ubygpXG5mdWxsQXBwLnJvdXRlKCcvZGV2aWNlcycsIGRldmljZXMpXG5mdWxsQXBwLnJvdXRlKCcvZXZlbnRzJywgZXZlbnRzKVxuZnVsbEFwcC5yb3V0ZSgnL3B1YmxpYy9hdXRoJywgYXV0aFJvdXRlcylcblxuLy8gQWRkIE9wZW5BUEkgZG9jdW1lbnRhdGlvbiB0byBwdWJsaWMgcm91dGVzXG5wdWJsaWNSb3V0ZXMuZ2V0KFxuICAgICcvb3BlbmFwaScsXG4gICAgb3BlbkFQSVNwZWNzKGZ1bGxBcHAsIHtcbiAgICAgICAgZG9jdW1lbnRhdGlvbjoge1xuICAgICAgICAgICAgaW5mbzoge1xuICAgICAgICAgICAgICAgIHRpdGxlOiAnVmF3a2VzIEdyaWRDdWJlIEFQSScsXG4gICAgICAgICAgICAgICAgdmVyc2lvbjogJzEuMC4wJyxcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogJ0FQSSBmb3IgaW50ZXJhY3Rpbmcgd2l0aCBWYXdrZXMgR3JpZEN1YmUgZGV2aWNlcy4nXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2VydmVyczogW10sXG4gICAgICAgICAgICB0YWdzOiBbXG4gICAgICAgICAgICAgICAgeyBuYW1lOiAnRGV2aWNlcycsIGRlc2NyaXB0aW9uOiAnRGV2aWNlIG1hbmFnZW1lbnQgZW5kcG9pbnRzJyB9LFxuICAgICAgICAgICAgICAgIHsgbmFtZTogJ0V2ZW50cycsIGRlc2NyaXB0aW9uOiAnRXZlbnQgZGF0YSBlbmRwb2ludHMnIH0sXG4gICAgICAgICAgICAgICAgeyBuYW1lOiAnQXV0aGVudGljYXRpb24nLCBkZXNjcmlwdGlvbjogJ1VzZXIgYXV0aGVudGljYXRpb24gZW5kcG9pbnRzJyB9XG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgY29tcG9uZW50czoge1xuICAgICAgICAgICAgICAgIHNlY3VyaXR5U2NoZW1lczoge1xuICAgICAgICAgICAgICAgICAgICBiZWFyZXJBdXRoOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAnaHR0cCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBzY2hlbWU6ICdiZWFyZXInLFxuICAgICAgICAgICAgICAgICAgICAgICAgYmVhcmVyRm9ybWF0OiAnSldUJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnRW50ZXIgSldUIHRva2VuIGZvciBhdXRoZW50aWNhdGlvbidcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzZWN1cml0eTogW1xuICAgICAgICAgICAgICAgIHsgYmVhcmVyQXV0aDogW10gfVxuICAgICAgICAgICAgXVxuICAgICAgICB9LFxuICAgIH0pXG4pXG5cbi8vIEFkZCBBUEkgZG9jdW1lbnRhdGlvbiBVSSB0byBwdWJsaWMgcm91dGVzXG5wdWJsaWNSb3V0ZXMuZ2V0KFxuICAgICcvZG9jcycsXG4gICAgYXBpUmVmZXJlbmNlKHtcbiAgICAgICAgdGhlbWU6ICdzYXR1cm4nLFxuICAgICAgICBzcGVjOiB7IHVybDogJy9wcm9kL3B1YmxpYy9vcGVuYXBpJyB9LFxuICAgIH0pXG4pXG5cbi8vIE1vdW50IHRoZSBwdWJsaWMgcm91dGVzIGF0IC9wdWJsaWNcbmFwcC5yb3V0ZSgnL3B1YmxpYycsIHB1YmxpY1JvdXRlcylcblxuLy8gQWRkIGEgbWlkZGxld2FyZSB0aGF0IGxvZ3MgYWxsIGluY29taW5nIHJlcXVlc3RzIGZvciBkZWJ1Z2dpbmdcbmFwcC51c2UoJyonLCBhc3luYyAoYywgbmV4dCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKGBSZXF1ZXN0IHJlY2VpdmVkOiAke2MucmVxLm1ldGhvZH0gJHtjLnJlcS5wYXRofWApO1xuICAgIGNvbnNvbGUubG9nKCdIZWFkZXJzOicsIEpTT04uc3RyaW5naWZ5KGMucmVxLmhlYWRlcigpKSk7XG4gICAgYXdhaXQgbmV4dCgpO1xuICAgIGNvbnNvbGUubG9nKGBSZXNwb25zZSBzdGF0dXM6ICR7Yy5yZXMuc3RhdHVzfWApO1xufSlcblxuLy8gQWRkIGF1dGhlbnRpY2F0aW9uIG1pZGRsZXdhcmUgdG8gcHJvdGVjdGVkIHJvdXRlc1xuLy8gUHJvdGVjdGVkIHJvdXRlcyBtdXN0IGJlIGRlZmluZWQgQUZURVIgbW91bnRpbmcgcHVibGljIHJvdXRlc1xuY29uc3QgcHJvdGVjdGVkUm91dGVzID0gbmV3IEhvbm8oKTtcbnByb3RlY3RlZFJvdXRlcy51c2UoJy8qJywgYXV0aCk7XG5wcm90ZWN0ZWRSb3V0ZXMucm91dGUoJy9kZXZpY2VzJywgZGV2aWNlcyk7XG5wcm90ZWN0ZWRSb3V0ZXMucm91dGUoJy9ldmVudHMnLCBldmVudHMpO1xuXG4vLyBNb3VudCB0aGUgcHJvdGVjdGVkIHJvdXRlcyBhdCB0aGUgcm9vdCBsZXZlbFxuYXBwLnJvdXRlKCcvJywgcHJvdGVjdGVkUm91dGVzKTtcblxuLy8gRXhwb3J0IHRoZSBoYW5kbGVyXG5leHBvcnQgY29uc3QgaGFuZGxlciA9IGhhbmRsZShhcHApOyJdfQ==