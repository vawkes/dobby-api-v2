import { z } from '@hono/zod-openapi';
export declare const companySchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
}, "strip", z.ZodTypeAny, {
    name: string;
    id: string;
    createdAt: string;
    updatedAt: string;
}, {
    name: string;
    id: string;
    createdAt: string;
    updatedAt: string;
}>;
export declare const UserRole: {
    readonly COMPANY_ADMIN: "COMPANY_ADMIN";
    readonly DEVICE_MANAGER: "DEVICE_MANAGER";
    readonly DEVICE_VIEWER: "DEVICE_VIEWER";
};
export type UserRole = typeof UserRole[keyof typeof UserRole];
export declare const companyUserSchema: z.ZodObject<{
    company_id: z.ZodString;
    user_id: z.ZodString;
    role: z.ZodNativeEnum<{
        readonly COMPANY_ADMIN: "COMPANY_ADMIN";
        readonly DEVICE_MANAGER: "DEVICE_MANAGER";
        readonly DEVICE_VIEWER: "DEVICE_VIEWER";
    }>;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
}, "strip", z.ZodTypeAny, {
    role: "COMPANY_ADMIN" | "DEVICE_MANAGER" | "DEVICE_VIEWER";
    createdAt: string;
    updatedAt: string;
    company_id: string;
    user_id: string;
}, {
    role: "COMPANY_ADMIN" | "DEVICE_MANAGER" | "DEVICE_VIEWER";
    createdAt: string;
    updatedAt: string;
    company_id: string;
    user_id: string;
}>;
export declare const companyDeviceSchema: z.ZodObject<{
    company_id: z.ZodString;
    device_id: z.ZodString;
    status: z.ZodEnum<["ACTIVE", "INACTIVE", "MAINTENANCE", "OFFLINE"]>;
    location: z.ZodOptional<z.ZodString>;
    installedAt: z.ZodOptional<z.ZodString>;
    lastSeenAt: z.ZodOptional<z.ZodString>;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
}, "strip", z.ZodTypeAny, {
    status: "ACTIVE" | "INACTIVE" | "MAINTENANCE" | "OFFLINE";
    device_id: string;
    createdAt: string;
    updatedAt: string;
    company_id: string;
    location?: string | undefined;
    installedAt?: string | undefined;
    lastSeenAt?: string | undefined;
}, {
    status: "ACTIVE" | "INACTIVE" | "MAINTENANCE" | "OFFLINE";
    device_id: string;
    createdAt: string;
    updatedAt: string;
    company_id: string;
    location?: string | undefined;
    installedAt?: string | undefined;
    lastSeenAt?: string | undefined;
}>;
export declare const createCompanySchema: z.ZodObject<{
    name: z.ZodString;
}, "strip", z.ZodTypeAny, {
    name: string;
}, {
    name: string;
}>;
export declare const updateCompanySchema: z.ZodObject<{
    name: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    name?: string | undefined;
}, {
    name?: string | undefined;
}>;
export declare const addUserToCompanySchema: z.ZodObject<{
    user_id: z.ZodString;
    role: z.ZodNativeEnum<{
        readonly COMPANY_ADMIN: "COMPANY_ADMIN";
        readonly DEVICE_MANAGER: "DEVICE_MANAGER";
        readonly DEVICE_VIEWER: "DEVICE_VIEWER";
    }>;
}, "strip", z.ZodTypeAny, {
    role: "COMPANY_ADMIN" | "DEVICE_MANAGER" | "DEVICE_VIEWER";
    user_id: string;
}, {
    role: "COMPANY_ADMIN" | "DEVICE_MANAGER" | "DEVICE_VIEWER";
    user_id: string;
}>;
export declare const updateUserRoleSchema: z.ZodObject<{
    role: z.ZodNativeEnum<{
        readonly COMPANY_ADMIN: "COMPANY_ADMIN";
        readonly DEVICE_MANAGER: "DEVICE_MANAGER";
        readonly DEVICE_VIEWER: "DEVICE_VIEWER";
    }>;
}, "strip", z.ZodTypeAny, {
    role: "COMPANY_ADMIN" | "DEVICE_MANAGER" | "DEVICE_VIEWER";
}, {
    role: "COMPANY_ADMIN" | "DEVICE_MANAGER" | "DEVICE_VIEWER";
}>;
export declare const addDeviceToCompanySchema: z.ZodObject<{
    device_id: z.ZodString;
    location: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    device_id: string;
    location?: string | undefined;
}, {
    device_id: string;
    location?: string | undefined;
}>;
export declare const updateDeviceSchema: z.ZodObject<{
    status: z.ZodOptional<z.ZodEnum<["ACTIVE", "INACTIVE", "MAINTENANCE", "OFFLINE"]>>;
    location: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    location?: string | undefined;
    status?: "ACTIVE" | "INACTIVE" | "MAINTENANCE" | "OFFLINE" | undefined;
}, {
    location?: string | undefined;
    status?: "ACTIVE" | "INACTIVE" | "MAINTENANCE" | "OFFLINE" | undefined;
}>;
export declare const companiesSchema: z.ZodArray<z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
}, "strip", z.ZodTypeAny, {
    name: string;
    id: string;
    createdAt: string;
    updatedAt: string;
}, {
    name: string;
    id: string;
    createdAt: string;
    updatedAt: string;
}>, "many">;
export declare const companyUsersSchema: z.ZodArray<z.ZodObject<{
    company_id: z.ZodString;
    user_id: z.ZodString;
    role: z.ZodNativeEnum<{
        readonly COMPANY_ADMIN: "COMPANY_ADMIN";
        readonly DEVICE_MANAGER: "DEVICE_MANAGER";
        readonly DEVICE_VIEWER: "DEVICE_VIEWER";
    }>;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
}, "strip", z.ZodTypeAny, {
    role: "COMPANY_ADMIN" | "DEVICE_MANAGER" | "DEVICE_VIEWER";
    createdAt: string;
    updatedAt: string;
    company_id: string;
    user_id: string;
}, {
    role: "COMPANY_ADMIN" | "DEVICE_MANAGER" | "DEVICE_VIEWER";
    createdAt: string;
    updatedAt: string;
    company_id: string;
    user_id: string;
}>, "many">;
export declare const companyDevicesSchema: z.ZodArray<z.ZodObject<{
    company_id: z.ZodString;
    device_id: z.ZodString;
    status: z.ZodEnum<["ACTIVE", "INACTIVE", "MAINTENANCE", "OFFLINE"]>;
    location: z.ZodOptional<z.ZodString>;
    installedAt: z.ZodOptional<z.ZodString>;
    lastSeenAt: z.ZodOptional<z.ZodString>;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
}, "strip", z.ZodTypeAny, {
    status: "ACTIVE" | "INACTIVE" | "MAINTENANCE" | "OFFLINE";
    device_id: string;
    createdAt: string;
    updatedAt: string;
    company_id: string;
    location?: string | undefined;
    installedAt?: string | undefined;
    lastSeenAt?: string | undefined;
}, {
    status: "ACTIVE" | "INACTIVE" | "MAINTENANCE" | "OFFLINE";
    device_id: string;
    createdAt: string;
    updatedAt: string;
    company_id: string;
    location?: string | undefined;
    installedAt?: string | undefined;
    lastSeenAt?: string | undefined;
}>, "many">;
