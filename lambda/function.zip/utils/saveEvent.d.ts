import { EventSchemaType } from "../events/eventsSchema";
/**
 * Saves an event to the DynamoDB table
 * @param event The event to save
 * @returns Promise<boolean> True if the event was saved successfully
 */
export declare function saveEventToDynamoDB(event: EventSchemaType): Promise<boolean>;
