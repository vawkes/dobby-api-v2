import { MiddlewareHandler } from 'hono';
export declare const auth: MiddlewareHandler;
