export declare function sendToDobby(deviceId: string, payload: ArrayBuffer): Promise<boolean>;
