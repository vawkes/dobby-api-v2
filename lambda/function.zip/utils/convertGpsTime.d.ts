declare const convertToGpsTimeEpoch: (utcTime: Date, leapSeconds?: number) => number;
export { convertToGpsTimeEpoch };
