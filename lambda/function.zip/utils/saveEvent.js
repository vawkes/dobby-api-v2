"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveEventToDynamoDB = saveEventToDynamoDB;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const util_dynamodb_1 = require("@aws-sdk/util-dynamodb");
const eventsSchema_1 = require("../events/eventsSchema");
const dynamodb = new client_dynamodb_1.DynamoDB({ "region": "us-east-1" });
/**
 * Saves an event to the DynamoDB table
 * @param event The event to save
 * @returns Promise<boolean> True if the event was saved successfully
 */
async function saveEventToDynamoDB(event) {
    try {
        // Flatten the event structure for DynamoDB
        const flattenedEvent = {
            event_id: event.event_id,
            event_type: event.event_type,
            device_id: event.event_data.device_id,
            event_sent: event.event_data.event_sent || false,
            event_ack: false // Default to false
        };
        // Add appropriate fields based on event type
        if (event.event_type === eventsSchema_1.EventType.INFO_REQUEST && 'timestamp' in event.event_data) {
            // For INFO_REQUEST, use timestamp field
            flattenedEvent.timestamp = event.event_data.timestamp;
        }
        else {
            // For all other event types, use start_time field
            if ('start_time' in event.event_data) {
                flattenedEvent.start_time = event.event_data.start_time;
            }
            // Add duration for event types that have it
            if ('duration' in event.event_data && event.event_data.duration !== undefined) {
                flattenedEvent.duration = event.event_data.duration;
            }
        }
        // Add device_id as a GSI partition key for querying by device
        flattenedEvent["device_id"] = event.event_data.device_id;
        // Transform the flattened event to the format expected by DynamoDB
        const marshalledEvent = (0, util_dynamodb_1.marshall)(flattenedEvent);
        // Save the event to DynamoDB
        await dynamodb.putItem({
            TableName: "DobbyEvent",
            Item: marshalledEvent
        });
        console.log(`Event ${event.event_id} saved to DynamoDB successfully`);
        return true;
    }
    catch (error) {
        console.error("Error saving event to DynamoDB:", error);
        return false;
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2F2ZUV2ZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsic2F2ZUV2ZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBdUJBLGtEQTZDQztBQXBFRCw4REFBb0Q7QUFDcEQsMERBQWtEO0FBQ2xELHlEQUFvRTtBQUVwRSxNQUFNLFFBQVEsR0FBRyxJQUFJLDBCQUFRLENBQUMsRUFBRSxRQUFRLEVBQUUsV0FBVyxFQUFFLENBQUMsQ0FBQztBQWN6RDs7OztHQUlHO0FBQ0ksS0FBSyxVQUFVLG1CQUFtQixDQUFDLEtBQXNCO0lBQzVELElBQUksQ0FBQztRQUNELDJDQUEyQztRQUMzQyxNQUFNLGNBQWMsR0FBbUI7WUFDbkMsUUFBUSxFQUFFLEtBQUssQ0FBQyxRQUFRO1lBQ3hCLFVBQVUsRUFBRSxLQUFLLENBQUMsVUFBVTtZQUM1QixTQUFTLEVBQUUsS0FBSyxDQUFDLFVBQVUsQ0FBQyxTQUFTO1lBQ3JDLFVBQVUsRUFBRSxLQUFLLENBQUMsVUFBVSxDQUFDLFVBQVUsSUFBSSxLQUFLO1lBQ2hELFNBQVMsRUFBRSxLQUFLLENBQUMsbUJBQW1CO1NBQ3ZDLENBQUM7UUFFRiw2Q0FBNkM7UUFDN0MsSUFBSSxLQUFLLENBQUMsVUFBVSxLQUFLLHdCQUFTLENBQUMsWUFBWSxJQUFJLFdBQVcsSUFBSSxLQUFLLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDakYsd0NBQXdDO1lBQ3hDLGNBQWMsQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUM7UUFDMUQsQ0FBQzthQUFNLENBQUM7WUFDSixrREFBa0Q7WUFDbEQsSUFBSSxZQUFZLElBQUksS0FBSyxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUNuQyxjQUFjLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDO1lBQzVELENBQUM7WUFFRCw0Q0FBNEM7WUFDNUMsSUFBSSxVQUFVLElBQUksS0FBSyxDQUFDLFVBQVUsSUFBSSxLQUFLLENBQUMsVUFBVSxDQUFDLFFBQVEsS0FBSyxTQUFTLEVBQUUsQ0FBQztnQkFDNUUsY0FBYyxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQztZQUN4RCxDQUFDO1FBQ0wsQ0FBQztRQUVELDhEQUE4RDtRQUM5RCxjQUFjLENBQUMsV0FBVyxDQUFDLEdBQUcsS0FBSyxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUM7UUFFekQsbUVBQW1FO1FBQ25FLE1BQU0sZUFBZSxHQUFHLElBQUEsd0JBQVEsRUFBQyxjQUFjLENBQUMsQ0FBQztRQUVqRCw2QkFBNkI7UUFDN0IsTUFBTSxRQUFRLENBQUMsT0FBTyxDQUFDO1lBQ25CLFNBQVMsRUFBRSxZQUFZO1lBQ3ZCLElBQUksRUFBRSxlQUFlO1NBQ3hCLENBQUMsQ0FBQztRQUVILE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxLQUFLLENBQUMsUUFBUSxpQ0FBaUMsQ0FBQyxDQUFDO1FBQ3RFLE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2IsT0FBTyxDQUFDLEtBQUssQ0FBQyxpQ0FBaUMsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUN4RCxPQUFPLEtBQUssQ0FBQztJQUNqQixDQUFDO0FBQ0wsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IER5bmFtb0RCIH0gZnJvbSBcIkBhd3Mtc2RrL2NsaWVudC1keW5hbW9kYlwiO1xuaW1wb3J0IHsgbWFyc2hhbGwgfSBmcm9tIFwiQGF3cy1zZGsvdXRpbC1keW5hbW9kYlwiO1xuaW1wb3J0IHsgRXZlbnRTY2hlbWFUeXBlLCBFdmVudFR5cGUgfSBmcm9tIFwiLi4vZXZlbnRzL2V2ZW50c1NjaGVtYVwiO1xuXG5jb25zdCBkeW5hbW9kYiA9IG5ldyBEeW5hbW9EQih7IFwicmVnaW9uXCI6IFwidXMtZWFzdC0xXCIgfSk7XG5cbi8vIEludGVyZmFjZSBmb3IgdGhlIGZsYXR0ZW5lZCBldmVudCBzdHJ1Y3R1cmUgdGhhdCBtYXRjaGVzIER5bmFtb0RCXG5pbnRlcmZhY2UgRmxhdHRlbmVkRXZlbnQge1xuICAgIGV2ZW50X2lkOiBzdHJpbmc7XG4gICAgZXZlbnRfdHlwZTogRXZlbnRUeXBlO1xuICAgIGRldmljZV9pZDogc3RyaW5nO1xuICAgIGV2ZW50X3NlbnQ6IGJvb2xlYW47XG4gICAgZXZlbnRfYWNrOiBib29sZWFuO1xuICAgIHN0YXJ0X3RpbWU/OiBzdHJpbmc7XG4gICAgdGltZXN0YW1wPzogc3RyaW5nO1xuICAgIGR1cmF0aW9uPzogbnVtYmVyO1xufVxuXG4vKipcbiAqIFNhdmVzIGFuIGV2ZW50IHRvIHRoZSBEeW5hbW9EQiB0YWJsZVxuICogQHBhcmFtIGV2ZW50IFRoZSBldmVudCB0byBzYXZlXG4gKiBAcmV0dXJucyBQcm9taXNlPGJvb2xlYW4+IFRydWUgaWYgdGhlIGV2ZW50IHdhcyBzYXZlZCBzdWNjZXNzZnVsbHlcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNhdmVFdmVudFRvRHluYW1vREIoZXZlbnQ6IEV2ZW50U2NoZW1hVHlwZSk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIHRyeSB7XG4gICAgICAgIC8vIEZsYXR0ZW4gdGhlIGV2ZW50IHN0cnVjdHVyZSBmb3IgRHluYW1vREJcbiAgICAgICAgY29uc3QgZmxhdHRlbmVkRXZlbnQ6IEZsYXR0ZW5lZEV2ZW50ID0ge1xuICAgICAgICAgICAgZXZlbnRfaWQ6IGV2ZW50LmV2ZW50X2lkLFxuICAgICAgICAgICAgZXZlbnRfdHlwZTogZXZlbnQuZXZlbnRfdHlwZSxcbiAgICAgICAgICAgIGRldmljZV9pZDogZXZlbnQuZXZlbnRfZGF0YS5kZXZpY2VfaWQsXG4gICAgICAgICAgICBldmVudF9zZW50OiBldmVudC5ldmVudF9kYXRhLmV2ZW50X3NlbnQgfHwgZmFsc2UsXG4gICAgICAgICAgICBldmVudF9hY2s6IGZhbHNlIC8vIERlZmF1bHQgdG8gZmFsc2VcbiAgICAgICAgfTtcblxuICAgICAgICAvLyBBZGQgYXBwcm9wcmlhdGUgZmllbGRzIGJhc2VkIG9uIGV2ZW50IHR5cGVcbiAgICAgICAgaWYgKGV2ZW50LmV2ZW50X3R5cGUgPT09IEV2ZW50VHlwZS5JTkZPX1JFUVVFU1QgJiYgJ3RpbWVzdGFtcCcgaW4gZXZlbnQuZXZlbnRfZGF0YSkge1xuICAgICAgICAgICAgLy8gRm9yIElORk9fUkVRVUVTVCwgdXNlIHRpbWVzdGFtcCBmaWVsZFxuICAgICAgICAgICAgZmxhdHRlbmVkRXZlbnQudGltZXN0YW1wID0gZXZlbnQuZXZlbnRfZGF0YS50aW1lc3RhbXA7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAvLyBGb3IgYWxsIG90aGVyIGV2ZW50IHR5cGVzLCB1c2Ugc3RhcnRfdGltZSBmaWVsZFxuICAgICAgICAgICAgaWYgKCdzdGFydF90aW1lJyBpbiBldmVudC5ldmVudF9kYXRhKSB7XG4gICAgICAgICAgICAgICAgZmxhdHRlbmVkRXZlbnQuc3RhcnRfdGltZSA9IGV2ZW50LmV2ZW50X2RhdGEuc3RhcnRfdGltZTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gQWRkIGR1cmF0aW9uIGZvciBldmVudCB0eXBlcyB0aGF0IGhhdmUgaXRcbiAgICAgICAgICAgIGlmICgnZHVyYXRpb24nIGluIGV2ZW50LmV2ZW50X2RhdGEgJiYgZXZlbnQuZXZlbnRfZGF0YS5kdXJhdGlvbiAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgZmxhdHRlbmVkRXZlbnQuZHVyYXRpb24gPSBldmVudC5ldmVudF9kYXRhLmR1cmF0aW9uO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gQWRkIGRldmljZV9pZCBhcyBhIEdTSSBwYXJ0aXRpb24ga2V5IGZvciBxdWVyeWluZyBieSBkZXZpY2VcbiAgICAgICAgZmxhdHRlbmVkRXZlbnRbXCJkZXZpY2VfaWRcIl0gPSBldmVudC5ldmVudF9kYXRhLmRldmljZV9pZDtcblxuICAgICAgICAvLyBUcmFuc2Zvcm0gdGhlIGZsYXR0ZW5lZCBldmVudCB0byB0aGUgZm9ybWF0IGV4cGVjdGVkIGJ5IER5bmFtb0RCXG4gICAgICAgIGNvbnN0IG1hcnNoYWxsZWRFdmVudCA9IG1hcnNoYWxsKGZsYXR0ZW5lZEV2ZW50KTtcblxuICAgICAgICAvLyBTYXZlIHRoZSBldmVudCB0byBEeW5hbW9EQlxuICAgICAgICBhd2FpdCBkeW5hbW9kYi5wdXRJdGVtKHtcbiAgICAgICAgICAgIFRhYmxlTmFtZTogXCJEb2JieUV2ZW50XCIsXG4gICAgICAgICAgICBJdGVtOiBtYXJzaGFsbGVkRXZlbnRcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc29sZS5sb2coYEV2ZW50ICR7ZXZlbnQuZXZlbnRfaWR9IHNhdmVkIHRvIER5bmFtb0RCIHN1Y2Nlc3NmdWxseWApO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3Igc2F2aW5nIGV2ZW50IHRvIER5bmFtb0RCOlwiLCBlcnJvcik7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG59ICJdfQ==